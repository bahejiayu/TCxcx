//应写入腾讯地图的key，并改文件名为config.js
module.exports = {
  key: "B5CBZ-QI5LX-ATA4J-ZETXT-QPAFZ-JCBIR",
}
