const app = getApp()
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    CardCur: 0,
    TabCur: 0,
    TabMenu:['首页','全部商品','猫咪物语','铲屎官必备'],
    VerticalNavTop: 0
  },
  cardSwiper(e) {
    this.setData({
      CardCur: e.detail.current
    })
  },
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      VerticalNavTop: (e.currentTarget.dataset.id - 1) * 50
    })
  },
  VerticalMain(e) {
    console.log(e.detail);
  }
})
