const API = require('../../utils/api')
const request = require('../../utils/request')
const wxReq = require('../../utils/wxRequest')
const commen = require('../../utils/commen')
const app = getApp();
Page({
  data: {
    code:'',
    HOST_URL: API.getHOSTURI()
  },
  onLoad: function (options) {
    this.setData({
      code:options.code
    })
  },
})