const request = require('utils/request');
var app = getApp();

App({
  onLaunch: function() {    
    this.globalData = {
      url: 'https://www.ulznkj.com',
      port1: ':810',
      port2: ':809',
      isShowRedPack: true,
      shareMessage: {
        title: 'U乐空间',
        desc: 'U乐智能空间',
        path: "/pages/home/home?redPId=",
        imageUrl: '/images/uleBg.jpg'
      },
    }
  }
})