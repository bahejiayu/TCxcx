// 配置域名
// var DOMAIN = "192.168.0.183:809";
var DOMAIN = "www.ulznkj.com";
// var DOMAIN = "192.168.0.101:809";




export default {
  getDomain: DOMAIN
}