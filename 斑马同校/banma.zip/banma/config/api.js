// 以下是业务服务器API地址
// 本机开发时使用
//var WxApiRoot = 'http://192.168.0.183:8082/sf/';
//var WxSocketRoot = 'ws://192.168.0.102:8082/sf/';
// 云平台部署时使用
var WxApiRoot = 'https://banma.laoyeshow.cn/sf/';
var WxSocketRoot = 'wss://banma.laoyeshow.cn/sf/';

module.exports = {
  globalData: {
    rankRefresh: 0,
    rankPageNum: 1
  },
  GetUserData: WxApiRoot + 'user/getUserData', //首页数据接口
  GetUserNew: WxApiRoot + 'user/getUserNew',
  LoginByWeiXin: WxApiRoot + 'user/loginByWeiXin',
  GetUserInfoExtend: WxApiRoot + 'user/ge   tUserInfoExtend',
  UpdateTempSchool: WxApiRoot + 'user/updateTempSchool',
  AddressList: WxApiRoot + 'user/addressList',
  AddAddress: WxApiRoot + 'user/addAddress',
  AddressDetail: WxApiRoot + 'user/addressDetail',
  DelAddress: WxApiRoot + 'user/delAddress',
  UserDefaultAddress: WxApiRoot + 'user/userDefaultAddress',
  UserAuthorizer: WxApiRoot + 'user/userAuthorizer',
  SendSms: WxApiRoot + 'user/sendSms',
  BindMobile: WxApiRoot + 'user/bindMobile',
  GetUserCash: WxApiRoot + 'user/getUserCash',
  GetUserCashDetail: WxApiRoot + 'user/getUserCashDetail',
  WithdrawMoney: WxApiRoot + 'user/withdrawMoney',
  RechargeList: WxApiRoot + 'user/rechargeList',
  WithdrawList: WxApiRoot + 'user/withdrawList',
  EarnOrderList: WxApiRoot + 'user/earnOrderList',
  SaveUserForm: WxApiRoot + 'user/saveUserForm',
  ConsumeList: WxApiRoot + 'user/consumeList',
  GetAcceptOrderOrg: WxApiRoot + 'user/getAcceptOrderOrg',
  UnBundlingMobil: WxApiRoot + 'user/unBundlingMobil',//设置解绑手机

  AllOrder: WxApiRoot + 'order/allOrder',
  AllOrder2: WxApiRoot + 'order/allOrder2',
  OrderDetail: WxApiRoot + 'order/orderDetail',
  AddOrder: WxApiRoot + 'order/addOrder',
  PayOrder: WxApiRoot + 'order/payOrder',
  AcceptOrder: WxApiRoot + 'order/acceptOrder',
  UpdateOrder: WxApiRoot + 'order/updateOrder',
  CancelOrder: WxApiRoot + 'order/cancelOrder',
  CancelOrderNotAgree: WxApiRoot + 'order/cancelOrderNotAgree',
  AllOrder: WxApiRoot + 'order/allOrder',
  PayRecharge: WxApiRoot + 'order/payRecharge',
  CompleteOrder: WxApiRoot + 'order/completeOrder',
  SendCompleteOrder: WxApiRoot + 'order/sendCompleteOrder',
  EvaluateOrder: WxApiRoot + 'order/evaluateOrder',

  MonthOrderRank: WxApiRoot + 'order/monthOrderRank', //
  TodayOrderAmt: WxApiRoot + 'order/todayOrderAmt',

  SysLabelList: WxApiRoot + 'sys/sysLabelList',
  BannerList: WxApiRoot + 'sys/bannerList',
  SysLabelList: WxApiRoot + 'sys/sysLabelList',
  NewSchoolApply: WxApiRoot + 'sys/newSchoolApply',
  SysCoopeation: WxApiRoot + 'sys/sysCoopeation',
  GetShareConfig: WxApiRoot + 'sys/getShareConfig',

  SchoolList: WxApiRoot + 'school/schoolList',
  SchoolList2: WxApiRoot + 'school/schoolList2',

  MessageList: WxApiRoot + 'message/messageList',
  UnreadMsgCount: WxApiRoot + 'message/unreadMsgCount',
  MessageDetailList: WxApiRoot + 'message/messageDetailList',
  SendMess: WxApiRoot + 'message/sendMess',
  HideMessage: WxApiRoot + 'message/hideMessage',
  OpenCustomerMess: WxApiRoot + 'message/openCustomerMess',
  BatchUpdateMessStatus: WxApiRoot + 'message/batchUpdateMessStatus',


  UploadFile: WxApiRoot + 'upload/uploadFile', //直接上传
  UploadFileSource: WxApiRoot + 'upload/uploadFileSource', //上传并保存到资源库 

  ManageIndex: WxApiRoot + 'manage/manageIndex',
  ProfileList: WxApiRoot + 'manage/frofileList',
  ProfileCount: WxApiRoot + 'manage/profileCount',
  ProfileUserDetail: WxApiRoot + 'manage/profileUserDetail',
  ProfileResult: WxApiRoot + 'manage/profileResult',
  AuthChangeOrder: WxApiRoot + 'manage/authChangeOrder',
  WithdrawOrderList: WxApiRoot + 'manage/withdrawOrderList',
  ProfileWithdrawOrder: WxApiRoot + 'manage/profileWithdrawOrder',
  UserList: WxApiRoot + 'manage/userList',
  CreateSysOrder: WxApiRoot + 'manage/createSysOrder',
  DelOrder: WxApiRoot + 'manage/delOrder',
  CreateVirtualPeople: WxApiRoot + 'manage/createVirtualPeople',
  SchoolApplyList: WxApiRoot + 'manage/schoolApplyList',
  CooperationList: WxApiRoot + 'manage/cooperationList',

  ServiceAgreement: WxApiRoot + 'agreement/serviceAgreement',//发单服务协议

  UserVouchers: WxApiRoot + 'vouchers/userVouchers',//代金券列表
  ReceiveVoucher: WxApiRoot + 'vouchers/receiveVoucher',//领取代金券
  FirstShow: WxApiRoot + 'vouchers/firstShow',//首次展示

  Permissions: WxApiRoot + 'user/permissions',//用户权限
  UnBundlingMobil: WxApiRoot + 'user/unBundlingMobil',//解绑手机
  ManageHome: WxApiRoot + 'managecash/manageHome',//合伙人资金首页
  ManageCashs: WxApiRoot + 'managecash/manageCashs',//合伙人钱包
  ManageWithdrawAppy: WxApiRoot + 'managecash/manageWithdrawAppy',//合伙人提现申请
  AdminList: WxApiRoot + 'manage/adminList',//管理员列表
  BindAdmin: WxApiRoot + 'manage/bindAdmin',//绑定管理员
  UnbindAdmin: WxApiRoot + 'manage/unbindAdmin',//解绑管理员

  WebsocketUrl: WxSocketRoot
};