// pages/home/choose.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orgList: [],
    type: 0, //进入页面方式 0 首页 1添加地址 2认证
    selectType: null, //0接单选择 1发单选择
    searchValue: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    if (options.type != undefined) {
      this.setData({
        type: options.type,
        selectType: options.selectType == undefined ? null : options.selectType
      })
    }
    if (options.searchValue != undefined) {
      this.setData({
        searchValue: options.searchValue
      })
    }
    this.orgList();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  onShareAppMessage: function() {

  },
  searchValueInput: function(e) {
    this.setData({
      searchValue: e.detail.value
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  orgList: function() {
    var that = this;
    var searchValue = this.data.searchValue;
    if (searchValue == "" || searchValue == " ") {
      searchValue = null
    }
    util.request(api.SchoolList, {
      orgName: searchValue,
      parentId: this.data.selectType
    }, "POST").then(function(res) {
      if (res.errno === 0) {
        var list = res.data.list;

        that.setData({
          // defaultOrgId: list[0].orgId,
          // defaultOrgName: list[0].orgName,
          orgList: list,
        })
      }
    })
  },
  chooseThisOrg: function(e) {
    console.log("e")
    if (this.data.type == 0) {
      wx.setStorageSync("defaultOrg", e.currentTarget.dataset.id);
      wx.setStorageSync("defaultOrgName", e.currentTarget.dataset.name);
    } else if (this.data.type == 1) {
      wx.setStorageSync("addAddressId", e.currentTarget.dataset.id);
    } else if (this.data.type == 2) {
      wx.setStorageSync("authOrgId", e.currentTarget.dataset.id);
    } else if (this.data.type == 3) {
      wx.setStorageSync("updateOrg", e.currentTarget.dataset.id);
      wx.setStorageSync("updateOrgName", e.currentTarget.dataset.name);
    } else if (this.data.type == 4) {
      wx.setStorageSync("defaultOrg", e.currentTarget.dataset.id);
      wx.setStorageSync("defaultOrgName", e.currentTarget.dataset.name);
      wx.setStorageSync("addressOrg", e.currentTarget.dataset.id);
      wx.setStorageSync("addressOrgName", e.currentTarget.dataset.name);
    } else if (this.data.type == 5) {
      wx.setStorageSync("sysOrderOrgId", e.currentTarget.dataset.id);
      wx.setStorageSync("sysOrderOrgName", e.currentTarget.dataset.name);
    }
    wx.navigateBack({
      delta: 1
    })
  },
  gotoNewSchoolPage: function() {
    wx.navigateTo({
      url: '/pages/ucenter/cooperation/school',
    })
  }
})