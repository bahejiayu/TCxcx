const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({
  data: {
    defaultOrgId: 0,
    auth: 0, //实名认证
  },
  onLoad() {
    var that = this;
    util.request(api.GetUserData, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          auth: obj.userInfo.type,
        })
      }
    })
    var id = wx.getStorageSync("defaultOrg");
    if (id != undefined && id !== "") {
      this.setData({
        defaultOrgId: id
      })
    }
    this.getRankList();
  },
  getRankList() {
    var that = this;
    util.request(api.TodayOrderAmt, {
      orgId: that.data.defaultOrgId
    }, "POST").then(function(res) {
      if (res.errno === 0) {
        that.setData({
          RankData: res.data
        })
      }
    })
    util.request(api.MonthOrderRank, {
      orgId: that.data.defaultOrgId
    }, "POST").then(function(res) {
      if (res.errno === 0) {
        var list = res.data.list;
        that.setData({
          RankList: list
        })
      }
    })
  },
  toAuth(){
    wx.navigateTo({
      url: '/pages/ucenter/auth/name',
    })
  }
})