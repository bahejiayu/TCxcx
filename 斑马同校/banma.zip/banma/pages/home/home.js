const util = require('../../utils/util.js');
const api = require('../../config/api.js');
const user = require('../../utils/user.js');
var today = new Date().getMonth() + "-" + new Date().getDate();
Page({
  data: {
    unreadMsg: 0,
    init: true,
    page: 'home',
    defaultOrgId: 0,
    defaultOrgName: '默认学校',
    orgList: [],
    loginAuth: false,
    bannerList: [{
      bannerId: 1,
      bannerPic: "http://image.weilanwl.com/sunfen/banner.jpg",
      bannerIndex: 0,
    }],
    statusType: ['类别', '快递', '代购', '其他'],
    priceType: ['价格', '由高到低', '由低到高'],
    sexType: ['性别', '限男生', '限女生'],
    getOrderType: ['状态', '可接单', '不可接单'],
    sexIndex: 0,
    statusIndex: 0,
    priceIndex: 0,
    getOrderIndex: 0,
    orderList: [],
    orderPageNum: 1, //订单当前页数
    over: true, //显示下页订单
    userId: 0,
    userSex: 0, //0男1女
    shareTitle: '收快递，就用顺蜂小程序',
    appUrl:'https://banma.laoyeshow.cn/sfimage/app',
    shareIcon: 'https://banma.laoyeshow.cn/sfimage/share_2.jpg',
    sharePath: '/pages/home/home',
    is_Ma: false,
    is_new:false,
    is_getCou: false,
    userVouchers:null

  },
  phone_:function(e){
    wx.login({
      success: function (e) {
        console.log(e)
      }
    })
      console.log(e)
  },
  close_Ma:function(){
      this.setData({
        is_Ma:false
      })
  },
  close_new:function(){
    this.setData({
      is_new: false
    })
  },
  toUcenter() {
    wx.switchTab({
      url: '/pages/ucenter/home/home',
    });
  },
  showModal(e) {
    var showName = e.currentTarget.dataset.modal;
    this.setData({
      modalName: showName
    })
  },
  closeModal(e) {
    this.setData({
      modalName: null
    })
  },
  onLoad: function() {
    wx.login({
      success:function(e){
        console.log(e)
      }
    })
    var mask = wx.getStorageSync("mask");
    if (mask === "") {
      let ShowMask = true;
      if (ShowMask) {
        this.setData({
          mask: 'step0'
        })
      } else {
        this.setData({
          mask: null
        })
      }
      wx.setStorageSync("mask", "true");
    } else {
      this.setData({
        mask: null
      })
    }
  
    this.getShareConfig();
    var that = this;
    var id = wx.getStorageSync("defaultOrg");
    if (id != undefined && id !== "") {
      this.setData({
        defaultOrgId: id
      })
    }
    wx.showLoading();
    this.bannerList();
    this.getRank();
    this.orgList();
    this.orderList();
    //授权
    if (wx.getStorageSync("userInfo") != null && wx.getStorageSync("userInfo") !== "" && wx.getStorageSync("userInfo") !== undefined)     {
      this.getUserNew();
      return false;
    }
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo'] === undefined || res.authSetting['scope.userInfo'] === "" || !res.authSetting['scope.userInfo']) {
          that.setData({
            loginAuth: true
          })
        } else {
          that.getUserInfo();
        }
      }
    });

  },
  bindGetUserInfo: function(e) {
    if (e.detail.errMsg != "getUserInfo:fail auth deny") {
      this.getUserInfo();
    }
    this.setData({
      loginAuth: false
    })
  },
  closeAuth() {
    this.setData({
      loginAuth: false
    })
  },
  onShow: function() {
    var id = wx.getStorageSync("defaultOrg");
    if (id != undefined && id !== "") {
      this.setData({
        defaultOrgId: id
      })
      this.replaceOrg(id);
      if (this.data.init) {
        this.setData({
          init: false
        })
        return false;
      }
      this.setData({
        // orderPageNum: 1,
        // orderList: []
      })
      var homeRefresh = wx.getStorageSync("homeRefresh");
      if (homeRefresh !== "") {
        this.setData({
          orderPageNum: 1,
          orderList: []
        })
        this.orderList(0, 0);
        this.bannerList();
        wx.removeStorageSync("homeRefresh");
      }
    } else {
      this.setData({
        init: false
      })
    }
    //获取用户最新信息,也用于判断用户是否登录
    this.getUserNew();
    this.getRank();
  },
  onShareAppMessage: function() {
    var that = this
    that.getShareConfig();
    return {
      title: that.data.shareTitle,
      path: that.data.sharePath,
      imageUrl: that.data.shareIcon,
      success: function(res) {}
    }
  },
  getUserInfo: function() {
    var that = this;
    wx.getUserInfo({
      success(res) {
        console.log(res)
        //判断用户是否存在系统，如果没有则新增
        user.loginByWeixin(res.userInfo,res.encryptedData,res.iv).then(res => {
          that.setData({
            loginAuth: false
          })
          wx.hideLoading()
          that.getUserNew();
        })
      }
    })
  },
  getShareConfig() {
    var that = this
    util.request(api.GetShareConfig, {}, "POST").then(function(res) {
      if (res.errno === 0) {
        that.setData({
          shareTitle: res.data.title,
          shareIcon: res.data.icon
        })
      }
    })
  },
  selectSex() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.sexType,
      success(res) {
        that.setData({
          sexIndex: res.tapIndex,
          // orderList: [],
          orderPageNum: 1
        })
        that.orderList(0, 0);
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  selectStatus() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.statusType,
      success(res) {
        that.setData({
          statusIndex: res.tapIndex,
          // orderList: [],
          orderPageNum: 1
        })
        that.orderList(0, 0);
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  selectPrice() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.priceType,
      success(res) {
        that.setData({
          priceIndex: res.tapIndex,
          // orderList: [],
          orderPageNum: 1
        })
        that.orderList(0, 0);
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  selectGetOrder() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.getOrderType,
      success(res) {
        that.setData({
          getOrderIndex: res.tapIndex,
          // orderList: [],
          orderPageNum: 1
        })
        that.orderList(0, 0);
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  nextMaskStep() {
    this.setData({
      mask: 'step1'
    })
  },
  closeMaskStep() {
    this.setData({
      mask: null
    })
  },
  toUcenter() {
    wx.switchTab({
      url: '/pages/ucenter/home/home',
    });
  },
  onPullDownRefresh: function() {
    this.setData({
      orderPageNum: 1,
      // orderList:[]
    })
    this.orderList(0, 0);

    wx.stopPullDownRefresh();
  },
  onReachBottom: function() {
    if (!this.data.over) {
      this.orderList();
    }

  },
  
  getUserNew: function() {
    var that = this;
    util.request(api.GetUserNew, {}, "POST").then(function(res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          userId: obj.userInfo.userId,
          userSex: obj.userInfo.userSex
        })
        if (obj.userInfo.userMobile != null) {
          wx.setStorageSync("userMobile", obj.userInfo.userMobile);
        }
        if (obj.userInfo.tempId != null) {
          wx.setStorageSync("tempId", obj.userInfo.tempId);

        }
        that.messageUnreadCount()
        wx.setStorageSync("userId", obj.userInfo.userId);
        wx.setStorageSync("userSex", obj.userInfo.userSex);
        wx.setStorageSync("userType", obj.userInfo.type); //认证情况
        if (obj.userInfo.type == 1) {
          if (wx.getStorageSync("acceptIds_" + today) == "") {
            that.getAcceptOrderOrg();
          }
          if(res.data.userInfo.coupons > 0){
            if (res.data.userVouchers.firstShow == "N"){//第一次展示

              util.request(api.FirstShow, {
                vouchersId: res.data.userVouchers.vouchersId
              }, "POST").then(function (res) {
                if (res.errno == 0) {
                  //没有业务
                }
              });

              that.setData({
                is_Ma: true
              });
            }else{
              that.setData({
                is_new: true
              });
            }
            that.setData({
              userVouchers: res.data.userVouchers
            });
          }
        }

      }
    })
  },
  //领取代金券
  receiveVoucher:function(e){
    var that = this;
    util.request(api.ReceiveVoucher, {
      userId:that.data.userId,
      vouchersId: that.data.userVouchers.vouchersId
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          is_Ma:false,
          is_new: false,
          is_getCou:true
        });
        var timeIndex=0;
        var intervalTime = setInterval(function(){
          timeIndex++;
          if(timeIndex > 2){
            that.setData({
              is_getCou: false
            });
            clearInterval(intervalTime);
          }
        },1000);
      }
    })
  },
  getAcceptOrderOrg: function() {
    var that = this;
    util.request(api.GetAcceptOrderOrg, {}, "POST").then(function(res) {
      if (res.errno === 0) {
        var obj = res.data;
        var ids = obj.acceptIds;
        wx.setStorageSync("acceptIds_" + today, ids); //一天缓存
      }
    })
  },
  bannerList: function() {
    var that = this;
    util.request(api.BannerList, {
      bannerOrg: this.data.defaultOrgId,
    }, "POST").then(function(res) {
      wx.hideLoading();
      if (res.errno === 0) {
        if (res.data.list == null || res.data.list.length == 0) {
          that.setData({
            bannerList: that.data.bannerList.concat({
              bannerId: 1,
              bannerPic: "http://image.weilanwl.com/sunfen/banner.jpg",
              bannerIndex: 0
            })
          })
        } else {
          let list = res.data.list;
          for (var i = 0; i < list.length; i++) {
            if (list[i].bannerPic.indexOf("imgFile") >= 0) {
              list[i].bannerPic = "https://banma.laoyeshow.cn" + list[i].bannerPic;
              list[i].linkPic = "https://banma.laoyeshow.cn" + list[i].linkPic;
            }
          }
          that.setData({
            bannerList: list,
          })
        }

      } else {
        that.setData({
          bannerList: that.data.bannerList.concat({
            bannerId: 1,
            bannerPic: "http://image.weilanwl.com/sunfen/banner.jpg",
            bannerIndex: 0
          })
        })
      }
    })
  },
  orgList: function() {
    var that = this;
    util.request(api.SchoolList, {}, "POST").then(function(res) {
      if (res.errno === 0) {
        var list = res.data.list;

        that.setData({
          // defaultOrgId:list[0].orgId,
          // defaultOrgName:list[0].orgName,
          orgList: list,
        })
        wx.setStorageSync("schoolList", list);
        that.replaceOrg(that.data.defaultOrgId);
      }
    })
  },
  orderList: function(e, type) {
    var that = this;
    var priceSort = this.data.priceIndex == 0 ? null : this.data.priceIndex
    var statusType = this.data.statusIndex == 0 ? null : this.data.statusIndex == 1 ? 0 : this.data.statusIndex == 2 ? 1 : 2
    var sex = this.data.sexIndex == 0 ? null : this.data.sexIndex == 1 ? 0 : 1
    var getOrderType = this.data.getOrderIndex == 0 ? 100 : this.data.getOrderIndex == 1 ? 101 : 102
    // getOrderIndex
    util.request(api.AllOrder, {
      status: getOrderType,
      pageNum: that.data.orderPageNum,
      pageSize: 20,
      remark: priceSort,
      orgId: this.data.defaultOrgId,
      type: statusType,
      orderSex: sex
    }, "POST").then(function(res) {
      wx.hideLoading()
      if (res.errno === 0) {
        var list = res.data.list;
        //解析时间 x小时前| mm-dd hh:mm
        //小于24小时86400000 
        var obj = null;
        var now = new Date().getTime();
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime3(obj.create_date);
          obj.type_desc = obj.type == 0 ? '快递' : obj.type == 1 ? '代购' : obj.type == 2 ? '打印' : '其他'
          obj.status = util.orderStatus(obj.status);
          obj.remark = util.nto(obj.remark)
        }

        if (list.length >= 20) {
          that.setData({
            orderPageNum: that.data.orderPageNum + 1,
            over: false
          })
        } else {
          that.setData({
            over: true
          })
        }
        if (type == 0) {
          that.setData({
            orderList: list
          })
        } else {
          that.setData({
            orderList: that.data.orderList.concat(list),
          })
        }

      } else {
        that.setData({
          over: true
        })
      }
    })
  },
  strCheck: function(str) {
    var strFormat = "0123456789";
    for (var i = 0; i < str.length; i++) {
      if (strFormat.indexOf(str.substr(i, 1)) == -1) {
        return false;
      }
    }
    return true;
  },
  nto: function(str) {
    var a = new Array();
    var b = "";
    var k = 0;
    for (var i = 0; i < str.length; i++) {
      a[i] = str.substr(i, 1);
      if (this.strCheck(a[i])) {
        k++;
      } else {
        k = 0;
      }
      if (k >= 4) {
        for (var j = i - 1; j <= i; j++) {
          a[j] = '*';
        }
      }
    }
    for (var i = 0; i < str.length; i++) {
      b += a[i]
    }
    return b;
  },
  selectOrg() { //跳转到选择学校页面
    wx.setStorageSync("homeRefresh", "data");
    wx.navigateTo({
      url: '/pages/home/choose?type=0',
    })
  },
  showMorePage() {
    wx.navigateTo({
      url: '/pages/task/list',
    })
  },
  showRank(){
    wx.navigateTo({
      url: '/pages/home/ranking',
    })
  },
  gotoBannerPage(e) {
    var linkPic = e.currentTarget.dataset.linkpic;
    var url = e.currentTarget.dataset.url+"?linkPic="+linkPic;
    console.log("url--->"+url);
    if (url !== "") {
      wx.navigateTo({
        url: url
      })
    }
  },
  gotoDetail: function(e) { //进入详情页
    var id = e.currentTarget.dataset.id;
    var uid = e.currentTarget.dataset.uid;
    var sex = e.currentTarget.dataset.sex;
    // if (uid != this.data.userId) {
    //   if (sex == 0) { //限制男
    //     if (this.data.userSex != 0) return false;
    //   } else if (sex == 1) { //限制女
    //     if (this.data.userSex != 1) return false;
    //   }
    // }
    wx.navigateTo({
      url: '/pages/task/info?orderId=' + id,
    })
  },
  replaceOrg: function(id) {
    var orgList = this.data.orgList;
    var obj = null;
    for (var i = 0; i < orgList.length; i++) {
      obj = orgList[i];
      if (obj.orgId == id) {
        this.setData({
          defaultOrgId: obj.orgId,
          defaultOrgName: obj.orgName
        })
        break;
      }
    }
  },
  messageUnreadCount: function(e) {
    var that = this
    util.request(api.UnreadMsgCount, {}, "POST").then(function(res) {
      if (res.errno === 0) {
        that.setData({
          unreadMsg: res.data.count
        })
      }
    })
  },
  //所有按钮埋点，用于推送
  formSubmit1: function(e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function(res) {
      if (res.errno === 0) {}
    })
    this.selectOrg();
  },
  getRank(){
    var that = this
    util.request(api.MonthOrderRank, {
      orgId: this.data.defaultOrgId
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          MonthRank: res.data.list
        })
      }
    })
  }
})