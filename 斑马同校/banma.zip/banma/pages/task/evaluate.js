const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({

    data: {
        rating: [{
            id: 0,
            title: '准时',
            scores: 3,
        }, {
            id: 1,
            title: '整洁',
            scores: 3,
        }, {
            id: 2,
            title: '礼貌',
            scores: 3,
        }],
        labelList:[],
        userId:0,
        orderId:0,
        inputCount:50,
        inputValue:''
    },
    onLoad:function(options){
      this.setData({
        orderId:options.orderId
      })
      this.labelList();
    },
    labelList:function(){
      var that = this;
      util.request(api.SysLabelList, { id: this.data.orderId }, "POST").then(function (res) {
        if (res.errno === 0) {
          that.setData({
            labelList:res.data.list
          })
        }
      })
    },
    setScores: function(e) {
        var id = e.currentTarget.dataset.id;
        var index = e.currentTarget.dataset.index;
        this.data.rating[id].scores = index;
        this.setData({
            rating: this.data.rating
        })
    },
    selectLabel:function(e){
      var list = this.data.labelList;
      var id=e.currentTarget.dataset.id;
      // var status = e.currentTarget.dataset.status==0?1:0;
      var obj=null
      for(var i=0;i<list.length;i++){
        obj=list[i];
        if(obj.labelId==id){
          obj.status=obj.status==0?1:0
          break;
        }
      }
      this.setData({
        labelList:list
      })

    },
    inputValue:function(e){
      var val = e.detail.value
      if (val.length>=51){
        this.setData({
          inputValue: this.data.inputValue,
          // inputCount: 50 - val.length
        })
        return ;
      }
      this.setData({
        inputValue: val,
        inputCount:50-val.length
      })
    },
  evaluateSubmit:function(){
    var level=0;
    var rating = this.data.rating;
    var labelList = this.data.labelList;
    var idStr="";
    var inputValue = this.data.inputValue;
    var that=this;
    for (var i = 0; i < rating.length;i++){
      var obj = rating[i];
      level += obj.scores
    }
    for (var i = 0; i < labelList.length; i++) {
      var obj = labelList[i];
      if(obj.status==1){
        idStr+=","+obj.labelId+"-"+obj.labelName
      }
    }
    if (idStr!=""){
      idStr = idStr.substring(1)
    }else{
      idStr=null;
    }
    // level = level/3;
    util.request(api.EvaluateOrder, { 
      orderId: this.data.orderId,
      content: inputValue,
      evaluateLevel: level,
      labelStr: idStr
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showToast({
          title: '评价完成',
          icon: 'success',
          duration: 1000
        })
        setTimeout(function(){
          wx.navigateBack({
            delta: 1
          })
        },1000)
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  }
})