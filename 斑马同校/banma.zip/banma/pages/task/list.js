// pages/task/list.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderList: [],
    orderPageNum: 1,//订单当前页数
    over: true,//显示下页订单
    userId: 0,
    defaultOrgId:0,
    userSex:0,
    statusType: ['类别', '快递', '代购','其他'],
    priceType: ['价格', '由高到低', '由低到高'],
    sexType: ['性别','限男生', '限女生'],
    sexIndex: 0,
    statusIndex: 0,
    priceIndex:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 缓存
    var id = wx.getStorageSync("defaultOrg");
    if (id != undefined && id !== "") {
      console.log(id)
      this.setData({
        defaultOrgId: id
      })
    }
    this.orderList();
    this.setData({
      userId: wx.getStorageSync("userId"),
      userSex: wx.getStorageSync("userSex"),
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.over) {
      this.orderList();
    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  selectSex() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.sexType,
      success(res) {
        that.setData({
          sexIndex: res.tapIndex,
          orderList: [],
          orderPageNum: 1
        })
        that.orderList();
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  selectStatus() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.statusType,
      success(res) {
        that.setData({
          statusIndex: res.tapIndex,
          orderList:[],
          orderPageNum:1
        })
        that.orderList();
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  selectPrice() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.priceType,
      success(res) {
        that.setData({
          priceIndex: res.tapIndex,
          orderList: [],
          orderPageNum: 1
        })
        that.orderList();
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  orderList: function () {
    var that = this;
    var priceSort = this.data.priceIndex == 0 ? null : this.data.priceIndex
    var type = this.data.statusIndex == 0 ? null : this.data.statusIndex == 1 ? 0 : this.data.statusIndex==2?1:2
    var sex = this.data.sexIndex == 0 ? null : this.data.sexIndex == 1 ? 0 : 1
    util.request(api.AllOrder, { 
      status: 100, 
      pageNum: that.data.orderPageNum, 
      pageSize: 20, 
      orderSex: sex, 
      remark: priceSort, 
      orgId: this.data.defaultOrgId,
      type:type,

      }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        //解析时间 x小时前| mm-dd hh:mm
        //小于24小时86400000 
        var obj = null;
        var now = new Date().getTime();
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime3(obj.create_date);
          obj.type_desc = obj.type == 0 ? '快递' : obj.type == 1 ? '代购' : '其他'
          obj.status = util.orderStatus(obj.status);
          obj.remark = util.nto(obj.remark)
        }

        if (list.length >= 20) {
          that.setData({
            orderPageNum: that.data.orderPageNum + 1,
            over: false
          })
        } else {
          that.setData({
            over: true
          })
        }
        that.setData({
          orderList: that.data.orderList.concat(list),
        })
      }
    })
  },
  gotoDetail: function (e) {//进入详情页
    var id = e.currentTarget.dataset.id;
    var uid = e.currentTarget.dataset.uid;
    var sex = e.currentTarget.dataset.sex;
    if (uid != this.data.userId) {
      if (sex == 0) {//限制男
        if (this.data.userSex != 0) return false;
      } else if (sex == 1) {//限制女
        if (this.data.userSex != 1) return false;
      }
    }
    wx.navigateTo({
      url: '/pages/task/info?orderId=' + id,
    })
  },

})