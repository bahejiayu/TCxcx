const util = require('../../utils/util.js');
const api = require('../../config/api.js');
var today = new Date().getMonth() + "-" + new Date().getDate();
Page({
    data: {
        step:0,
        userType:0,//未认证0 已认证 1
        price: 1,
        tempPrice: 1,
        lowPrice: 1,
        close: false,
        closeIndex:2,
        orderId:0,
        earnUser:null,
        pubImgSourceList:[],
        sysOrg:null,
        user:null,
        userId:0,
        userSex:0,
        userAddress:null,
        userOrder:null,
        startDatUnit:null,
        startDateYMD:null,
        startDateHM:null,
        endDatUnit: null,
        endDateYMD: null,
        endDateHM: null,
        messageId:null,
        earnUserLabel:[],
        lessHour:null
    },
    onLoad(e) {
        this.setData({
          orderId:e.orderId,
          userId:wx.getStorageSync("userId"),
          userSex: wx.getStorageSync("userSex"),
        })
      var userType = wx.getStorageSync("userType")
      userType = userType==""?0:userType;
        this.setData({
          userType: userType
        })
        // if (e.role) {
        //     this.setData({ role: e.role })
        // }
        // if (e.step) {
        //     this.setData({ step: e.step })
        // }
        // if (e.close) {
        //     this.setData({ close: e.close })
        // }
        // if (e.closer) {
        //     this.setData({ closer: e.closer })
        // }
        
    },
    onShow:function(){
      this.orderDetail();
    },
    showModal: function(e) {
        var showName = e.currentTarget.dataset.modal;
        this.setData({
            modalName: showName
        })
    },
    closeModal(e) {
        this.setData({
            modalName: null
        })
    },
    closeOrder(e) {
      var that=this;
      var id=e.currentTarget.dataset.id;
      var appendStr ="确定要取消订单？";
      /*
      if (this.data.userOrder.userId==this.data.userId){
        if(this.data.userOrder.status>1){
          appendStr = "取消订单需要及时跟对方联系，双方协商同意后才能有效取消订单！";
        }
      }else{
        appendStr = "取消订单需要及时跟对方联系，双方协商同意后才能有效取消订单！";
      }
      */
      //发单人取消订单(已接单)
      if (this.data.userOrder.userId == this.data.userId && 
          this.data.userOrder.earnUserId !=null && 
          this.data.userOrder.status==2) {

        appendStr += "订单已接单，取消需要接单人同意，同意后将返还80%金额给发单人，扣除20%手续费";
      }
      //接单人取消订单（已接单）
      if (this.data.userOrder.earnUserId == this.data.userId &&
        this.data.userOrder.status == 2) {
        appendStr += "你已接单，取消会被扣款，扣除20%，余额负数不可接单";
      }
      wx: wx.showModal({
          title: '取消订单',
        content:appendStr,
          success: (result) => {
              if (result.confirm) {
                that.cancelOrderSubmit(id);
              }
          },
      });
    },
  closeOrderAccept(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
      wx: wx.showModal({
        title: '取消订单',
        content: '同意取消订单吗？同意取消后订单作废，金额返还',
        success: (result) => {
          if (result.confirm) {
            that.cancelOrderSubmit(id);
          }
        },
      });
  },
  closeOrderNotAgree(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    // if (this.data.step <= 1) {
      wx: wx.showModal({
        title: '取消订单',
        content: '确认不同意取消订单后，订单将继续进行，是否确认？',
        success: (result) => {
          if (result.confirm) {
            that.notAgreeSubmit(id);
          }
        },
      });
    // }
    // else {
    //   this.setData({ modalName: 'closeOrder' })
    // }
  },
    showInput() {
        this.setData({
            showInput: true
        })
    },
    inputPrice(e) {
        this.setData({
            tempPrice: e.detail.value
        })
    },
    selectPrice(e) {
        this.setData({
            tempPrice: e.currentTarget.dataset.price
        })
    },
    finishPrice() {//添加小费
      var that=this
      var price = this.data.tempPrice;
        this.setData({
            price: this.data.tempPrice,
            modalName: null
        })
      //添加临时单，唤起微信支付
      util.request(api.UpdateOrder, { orderId: this.data.orderId, amt:price }, "POST").then(function (res) {
        wx.requestPayment({
          'timeStamp': res.data[0].timeStamp,
          'nonceStr': res.data[0].nonceStr,
          'package': res.data[0].package,
          'signType': 'MD5',
          'paySign': res.data[0].paySign,
          'success': function (res) {
            wx.showToast({
              title: '添加小费成功。',
              icon: 'success',
              duration: 2000
            })
            that.orderDetail();
          },
          'fail': function (res) {
            console.log("cancel pay");
          }
        })
      })
    },
  payOrder:function(){//支付订单
    var that=this;
    //添加临时单，唤起微信支付
    util.request(api.PayOrder, { id: this.data.orderId}, "POST").then(function (res) {
      wx.requestPayment({
        'timeStamp': res.data[0].timeStamp,
        'nonceStr': res.data[0].nonceStr,
        'package': res.data[0].package,
        'signType': 'MD5',
        'paySign': res.data[0].paySign,
        'success': function (res) {
          wx.showToast({
            title: '支付成功。',
            icon: 'success',
            duration: 2000
          })
          that.orderDetail();
        },
        'fail': function (res) {
          console.log("cancel pay");
        }
      })
    })
  },
  orderDetail:function(){//订单详情
    var that=this;
    util.request(api.OrderDetail, { orderId:this.data.orderId }, "POST").then(function (res) {
      if (res.errno === 0) {
        var userAddress=res.data.userAddress
        var userOrder = res.data.userOrder
        if (userOrder.status == 4 || userOrder.status == 7 || userOrder.status == 10 || userOrder.status == 11 || userOrder.status == 12){
          if (userOrder.status == 10 || userOrder.status == 11 || userOrder.status == 12){
            that.setData({
              closeIndex:1
            })
          }else{
            that.setData({
              closeIndex: 2
            })
          }
          that.setData({
            close:true
          })
        }else{
          close:false
        }
        if (that.data.userId == userOrder.userId || that.data.userId == userOrder.earnUserId){
          
        }else{
          userOrder.remark = util.nto(userOrder.remark)
          userOrder.orderDesc=null
        }
        userOrder.createDate2 = util.formatTime5(new Date(userOrder.createDate));
        userOrder.createDate = util.formatTime3(userOrder.createDate);
        // userOrder.orderStartDate = util.formatTime(new Date(userOrder.orderStartDate));
        // userOrder.orderEndDate = util.formatTime(new Date(userOrder.orderEndDate));
        userOrder.startWeekDay = util.getWeekDay(new Date(userOrder.orderStartDate));
        userOrder.endWeekDay = util.getWeekDay(new Date(userOrder.orderEndDate));
        userOrder.orderStartDate = userOrder.orderStartDate == null ? '' : util.formatTime(new Date(userOrder.orderStartDate));
        userOrder.orderEndDate = userOrder.orderEndDate == null ? '' : util.formatTime(new Date(userOrder.orderEndDate)) ;
        var step = userOrder.status == 0 ? -1 : userOrder.status == 1 ? 0 : userOrder.status == 2 ? 1 : userOrder.status == 3 ? 2 : userOrder.status == 9 ? 3 : userOrder.status==4?4:4;
        if (userAddress!=null&&userAddress.contactMobile.length>=11){
          userAddress.contactMobile = (userOrder.userId == that.data.userId || userOrder.earnUserId == that.data.userId) ? userAddress.contactMobile : userAddress.contactMobile.substring(0, 2) + "*******" + userAddress.contactMobile.substring(9);
        }
        if (userAddress!=null){
          userAddress.apartmentRoom = (userOrder.userId == that.data.userId || userOrder.earnUserId == that.data.userId) ? userAddress.apartmentRoom : "****";
        }
        var lessHour=null;
        if (userOrder.deliverDate!=null){
          
          var deliverCompleteTime = new Date().getTime() - new Date(userOrder.deliverDate).getTime();
          lessHour = (deliverCompleteTime / (1000 * 60 * 60)) < 1 ? 47 : 48 - (deliverCompleteTime / (1000 * 60 * 60))
          lessHour = lessHour <= 0 ? null : lessHour.toFixed(0)
        }
        
        that.setData({
          earnUser: res.data.earnUser,
          pubImgSourceList: res.data.pubImgSourceList,
          sysOrg: res.data.sysOrg,
          user: res.data.user,
          userAddress: userAddress,
          userOrder: userOrder,
          step: step,
          earnUserLabel: res.data.earnUserLabel,
          lessHour: lessHour,
          messageId: res.data.messageId == undefined ? null : res.data.messageId
        })
      }
    })
  },
  previewImg: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src + '', // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  },
  cancelOrderSubmit:function(id){
    var that = this;
    var type=0;
    if(this.data.userId==this.data.userOrder.earnUserId){
      type=1;
    }
    util.request(api.CancelOrder, { id: id, type: type }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.orderDetail();
      }else{
        wx.showModal({
          title: '提示',
          content: "取消订单失败："+res.errmsg,
        })
      }
    })
  },
  notAgreeSubmit: function (id) {
    var that = this;
    var type = 0;
    if (this.data.userId == this.data.userOrder.earnUserId) {
      type = 1;
    }
    util.request(api.CancelOrderNotAgree, { id: id }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.orderDetail();
      } else {
        wx.showModal({
          title: '提示',
          content: "不同意取消订单失败：" + res.errmsg,
        })
      }
    })
  },
  cancelOrderFESubmit: function (id) {
    var that = this;
    util.request(api.CancelOrder, { id: id }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.orderDetail();
      } else {
        wx.showModal({
          title: '提示',
          content: "取消订单失败：" + res.errmsg,
        })
      }
    })
  },
  acceptOrder:function(){//接单
  //判断当前用户接单校区是否在
    var acceptIds=wx.getStorageSync("acceptIds_" + today);
    if (acceptIds==""){
      wx.showModal({
        title: '提示',
        content: '您的接单学校不属于当前订单的学校，不能进行接单哦。',
        showCancel: false,
      })
      return false;
    }
    var flag=false;
    acceptIds = acceptIds.split(",");
    for (var i = 0; i < acceptIds.length;i++){
      if (acceptIds[i] == this.data.userOrder.orgId){
        flag=true;
        break;
      }
    }
    if (!flag){
      wx.showModal({
        title: '提示',
        content: '您的接单学校不属于当前订单的学校，不能进行接单哦!',
        showCancel: false,
      })
      return false;
    }
    var that = this;
    util.request(api.AcceptOrder, { id: this.data.orderId }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showToast({
          title: '抢单成功！',
          icon: 'success',
          duration: 2000
        })
        that.orderDetail()
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
          showCancel: false,
        })
      }
    })
  },
  sendCompleteConfirm:function(){//确认送达提示 接单人
    var that=this
    wx.showModal({
      title: '操作提示',
      content: '确定订单已送达吗？',
      success: (result) => {
        if (result.confirm) {
          that.sendCompleteOrder();
        }
      },
    })
  },
  sendCompleteOrder: function () {//确认送达 接单人
    var that = this;
    util.request(api.SendCompleteOrder, { id: this.data.orderId }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '提交送达成功，请等待同学确认已送达',
          showCancel: false,
        })
        that.orderDetail();
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  completeOrderConfirm: function () {//确认已送达提示 发单人
    var that = this
    wx.showModal({
      title: '操作提示',
      content: '确定订单已送达吗？',
      success: (result) => {
        if (result.confirm) {
          that.completeOrder();
        }
      },
    })
  },
  completeOrder: function () {//确认已送达 发单人
    var that = this;
    util.request(api.CompleteOrder, { id: this.data.orderId }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showToast({
          title: '交易完成！',
          icon: 'success',
          duration: 2000
        })
        that.orderDetail();
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  gotoAuth:function(){
    if(this.data.userId==0||this.data.userId==null||this.data.userId==""){
      wx.redirectTo({
        url: '/pages/ucenter/home/home',
      })
      return false;
    }
    wx.navigateTo({
      url: '/pages/ucenter/auth/name',
    })
  },
  evaluatePage: function (e) {
    wx.navigateTo({
      url: '/pages/task/evaluate?orderId='+e.currentTarget.dataset.id,
    })
  },
  callUser:function(e){
    var mobile=e.currentTarget.dataset.mobile;
    if(mobile==""){
      wx.showModal({
        title: '提示',
        content: '没有绑定电话',
        showCancel: false,
      })
      return false;
    }
    wx.makePhoneCall({
      phoneNumber: mobile
    })
  },
  sendMess:function(e){
    wx.setStorageSync("targetHeadIcon", e.currentTarget.dataset.icon)
    wx.setStorageSync("messageId", e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/chat/info?messageId=' + this.data.messageId + "&otherUserId=" + e.currentTarget.dataset.uid,
    })
  },
  //所有按钮埋点，用于推送
  formSubmit1: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    this.gotoAuth();
  },
})