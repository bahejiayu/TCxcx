// pages/chat/list.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({
  data: {
    messageList:[],
    pageNum:1,
    userId:0,
    showDel:false,
    over:false
  },
  onLoad: function (options) {
    this.setData({
      userId: wx.getStorageSync("userId")
    })
    this.messageList();
  },
  onShow: function () {
    var messageList = this.data.messageList;
    var messageId = wx.getStorageSync("messageId") == "" ? "" : parseInt(wx.getStorageSync("messageId"));
    console.log(messageId);
    if (messageId == "") return false;
    for (var i = 0; i < messageList.length; i++) {
      if (messageId == messageList[i].mess_id) {
        messageList[i].send_unread_num = 0;
        messageList[i].target_unread_num = 0;
        break;
      }
    }
    this.setData({
      messageList: messageList
    })
  },
  closeDel(){
    var list = this.data.messageList;
    for(var i=0;i<list.length;i++){
      list[i].showDel=false
    }
    this.setData({
      messageList: list
    })  
  },
  showDel(e){
    var idx=e.currentTarget.dataset.idx
    var list = this.data.messageList;
    list[idx].showDel=true
    this.setData({
      messageList: list
    })
  },
  delItem(e){
    var id = e.currentTarget.dataset.id
    var idx = e.currentTarget.dataset.idx
    let that =this;
    wx.showModal({
      title: '提示',
      content: '确定删除这条会话消息？',
      success(res) {
        if (res.confirm) {
          that.delSubmit(id, idx)
          // that.closeDel();
        } else if (res.cancel) {
          that.closeDel();
        }
      }
    })
  },
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  messageList: function () {
    var that = this;
    util.request(api.MessageList, { pageNum: this.data.pageNum,pageSize:1000}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        var obj=null;
        for(var i=0;i<list.length;i++){
          obj=list[i];
          if(that.data.userId==obj.send_user_id){
            // console.log(obj.target_mess)
            obj.showDel=false;
            if (obj.target_mess != null && obj.target_mess!=undefined&&obj.target_mess.indexOf("AppData")>=0){
              obj.target_mess="[图片]";
            }
            obj.target_date = obj.target_date==null?'': util.formatTime4(obj.target_date);
            obj.hide = obj.send_hide==1?true:false
          }else{
            obj.send_date = obj.send_date==null?'': util.formatTime4(obj.send_date);
            obj.hide = obj.target_hide == 1 ? true : false
          }
        }
        that.setData({
          messageList: list,
        })
        setTimeout(()=>{
          // 隐藏导航栏加载框
          wx.hideNavigationBarLoading();
          // 停止下拉动作
          wx.stopPullDownRefresh();
          that.setData({
            over: false
          })
        },1000)
      }
    })
  },
  delSubmit: function (id,idx) {
    var that = this;
    util.request(api.HideMessage, { messageId: id }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = that.data.messageList;
        list[idx].hide = true
        that.setData({
          messageList: list
        })
        that.closeDel();
      }
    })
  },
  gotoDetail:function(e){
    wx.setStorageSync("targetHeadIcon", e.currentTarget.dataset.icon)
    wx.setStorageSync("messageId", e.currentTarget.dataset.id)
    wx.navigateTo({
      url: 'info?messageId=' + e.currentTarget.dataset.id +"&otherUserId="+e.currentTarget.dataset.uid,
    })
  },
  onPullDownRefresh: function () {
    // 显示顶部刷新图标
    wx.showNavigationBarLoading();
    this.setData({
      over:true
    })
    this.messageList();
  },
})