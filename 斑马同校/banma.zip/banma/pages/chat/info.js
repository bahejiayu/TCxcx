// pages/chat/info.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
const user = require('../../utils/user.js');
var socketOpen = false
var socketMsgQueue = []
var otherUserId = 0;//对方id
var hearts;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    messageId:0,
    messageList:[],
    pageIndex:9999,//每页的最后一条记录的下标
    pageNum:1,
    pageDone:false,
    userId:0,//自己id
    type:0,
    userHeadIcon:'',
    inputFocus:false,
    inputValue:'',
  },
  onLoad: function (options) {
    var that=this;
    //上个页面传标识来，判断自己是主还是副
    this.setData({
      messageId: options.messageId == undefined ? 9 : options.messageId,
      type:1,//主
      userId: wx.getStorageSync("userId"),
      userHeadIcon: wx.getStorageSync("userHeadIcon"),
      targetHeadIcon: wx.getStorageSync("targetHeadIcon"),
    })
    otherUserId = options.otherUserId == undefined ? 6 : options.otherUserId;
    console.log(otherUserId)
    this.messageList(0);
    this.updateUnreadStatus();
    //加入socket即时聊天,设置每20秒心跳，防止掉线
    this.connectWebsocket();
    // hearts = setInterval(function () {
    //   that.sendHeartBeat()
    // }, 1000);
  },
  onHide:function(){
    // console.log("hide?")
    // wx.closeSocket();
  },
  onUnload: function () {
    wx.closeSocket();
    clearInterval(hearts)
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    if(!this.data.pageDone){
      this.messageList();
    }
    wx.stopPullDownRefresh();
  },
  connectWebsocket: function () {
    var that = this;
    wx.connectSocket({
      url: api.WebsocketUrl +'websocket/' + this.data.userId,
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      method: "GET"
    })
    wx.onSocketOpen(function (res) {
      console.log('WebSocket连接已打开！')
      socketOpen = true
      for (var i = 0; i < socketMsgQueue.length; i++) {
        sendSocketMessage(socketMsgQueue[i])
      }
      socketMsgQueue = []
      // let that=this;
      
    })
    wx.onSocketError(function (res) {
      console.log('WebSocket连接打开失败，请检查！')
    })
    wx.onSocketMessage(function (res) {
      console.log('收到服务器内容：' + res.data)
      var uid = res.data.split("|")[0];
      var text = res.data.split("|")[1];
      //如果是当前聊天用户发来的信息，则直接显示
      if (otherUserId==uid){
        var arr = [{
          content: text,
          createDate: util.formatTime4(new Date().getTime()),
          sendType: 0,
          sendUserId: uid,
          // targetUserId:uid
        }]
        that.setData({
          messageList: that.data.messageList.concat(arr)
        })
        that.scrollToBottom();
        //更新所有消息为已读
        that.updateUnreadStatus();
      }

    })
  },
  sendSocketMsg: function (content) {//通过socket推送新消息
    console.log(socketOpen)
    if (socketOpen) {
      wx.sendSocketMessage({
        data: content + '|' + otherUserId
      })
    } else {
      socketMsgQueue.push(msg)
    }
  },
  sendHeartBeat: function () {//通过socket推送新消息
    console.log('heart beat')
    if (socketOpen) {
      // wx.sendSocketMessage({
      //   data: ''
      // })
    }
  },
  messageList: function (t) {//信息详情列表
    var that = this;
    util.request(api.MessageDetailList, { pageNum: this.data.pageNum,pageSize:10, messageId: this.data.messageId }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        if(list!=null&&list.length>0){
          list.reverse();//数据反转
        }
        if(list.length>=10){//当页数量满时，页脚++
          that.setData({
            pageNum: that.data.pageNum+1
          })
        }else{
          that.setData({
            pageDone: true//标记没有更多记录
          })
        }
        var obj = null;
        for (var i = 0; i <list.length; i++) {
          obj = list[i];
          if (that.data.pageIndex <= obj.detailNum){
            obj.sendType=9999
          }
          obj.createDate = util.formatTime4(obj.createDate);
          if (that.data.userId == obj.sendUserId) {
            //自己右边
          } else {
            // 左边
          }
        }
        that.setData({
          messageList: list.concat( that.data.messageList)
        })
        if (list != null && list.length > 0) {
          //记录每页最后下标，获取下一页时，大于等于该下标的，直接跳过
          that.setData({
            pageIndex: list[0].detailNum
          })
        }
        //置底
        if(t==0){
          that.scrollToBottom();
        }
      }
    })
  },
  bindKeyInput:function(e){//文本输入
    this.setData({
      inputValue: e.detail.value
    })
  },
  sendPhoto:function(){//发送图片
    var that=this;
    wx.chooseImage({
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        wx.uploadFile({
          url: api.UploadFile, //仅为示例，非真实的接口地址
          filePath: tempFilePaths[0],
          name: 'file',
          formData: {
            'user': 'test'
          },
          success: function (res) {
            var data = JSON.parse(res.data);
            var imgPath = "https://banma.laoyeshow.cn/imgFile/" + data.data.fileName;
            that.sendMsg(null,imgPath);
          }
        })
      }
    })
  },
  sendMsg:function(e,url){//发送文本消息
    var that = this;
    var type = this.data.type;
    var sendUserId=null;
    var targetUserId=null;
    console.log(type)
    if (type==0){
      targetUserId=this.data.userId;
      sendUserId=otherUserId
    }else{
      targetUserId = otherUserId;
      sendUserId=this.data.userId
    }
    var content = this.data.inputValue;
    var sendType = 0;
    if (url!=undefined){
      content = url;
      sendType=1;
    }
    if (content==''){
      return false;
    }
    util.request(api.SendMess, { 
      messageId:that.data.messageId,
      sendUserId: sendUserId,
      targetUserId: targetUserId,
      content:content,
      sendType: sendType
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.sendSocketMsg(content);
        var arr=[{
          content: content,
          createDate: util.formatTime4(new Date().getTime()),
          sendType: sendType,
          sendUserId:that.data.userId,

        }]
        that.setData({
          inputValue:'',
          messageList: that.data.messageList.concat(arr)
        })
        that.scrollToBottom();
      }
    })
  },
  updateUnreadStatus:function(){
    util.request(api.BatchUpdateMessStatus, {messageId: this.data.messageId }, "POST").then(function (res) {
    });
  },
  scrollToBottom:function(){//置底
    wx.createSelectorQuery().select('.chat').boundingClientRect(function (rect) {
      wx.pageScrollTo({
        scrollTop: 9999999,
        duration: 0
      })
    }).exec()
  },
  getUserInfo: function () {//掉线获取用户信息
    var that = this;
    wx.getUserInfo({
      success(res) {
        user.loginByWeixin(res.userInfo).then(res => {
          that.messageList();
          wx.hideLoading()
        })
        
      }
    })
  },
  previewImg:function(e){
    wx.previewImage({
      current: e.currentTarget.dataset.src+'', // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  },
  formSubmit: function (e) {
    var that = this
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    this.sendMsg();
  },

})