// pages/manager/getDetail/getDetail.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    leftValue:0,
    manageTheDayProfits:0,//今日分润
    manageCash:null,//合伙人资金
    profitss:[],//分润明细
    withdraws:[],//提现明细
    userInfo:null
  },
  tog_nav:function(e){
      this.setData({
        leftValue:e.target.dataset.value
      });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: wx.getStorageSync("userInfo")
    });
    this.manageIndex();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //初始化加载数据
  manageIndex(){
    var that=this;
    util.request(api.ManageHome, {userId:that.data.userInfo.userId},"POST").then(function(e){
      if(e.errno==0){
        var _profistMonthList = e.data.profitsList;
        var _tmpProfitsMonthList=[];
        for (var i = 0; i < _profistMonthList.length; i++) {
          var tempObjI = _profistMonthList[i];
          var _tmpProfistMonth ={};
          _tmpProfistMonth.groupMonth = _profistMonthList[i].groupMonth;
          var _tmpProfistList=[];
          for (var j = 0; j < tempObjI.profitsList.length; j++) {
            var tmpObjJ = tempObjI.profitsList[j];
            var _tmpProfist ={};
            _tmpProfist.userName = tmpObjJ.userName;
            _tmpProfist.userHeadIcon = tmpObjJ.userHeadIcon;
            _tmpProfist.type = tmpObjJ.type;
            _tmpProfist.merchants = tmpObjJ.merchants;
            _tmpProfist.createDate = util.formatTime2(new Date(tmpObjJ.createDate));
            _tmpProfist.orderAmt = tmpObjJ.orderAmt;
            _tmpProfist.remark = tmpObjJ.remark;
            _tmpProfistList[j] = _tmpProfist;
          }
          _tmpProfistMonth.profitsList = _tmpProfistList;
          _tmpProfitsMonthList[i] = _tmpProfistMonth;
        }
        var tmpWithdrawList = e.data.withdrawList;
        var _tmpWithdrawMonthList = [];
        if (tmpWithdrawList.length > 0){
          for (var i = 0; i < tmpWithdrawList.length; i++) {
            var tmpObjI = tmpWithdrawList[i];
            var _tmpWithdrawMonth = {};
            _tmpWithdrawMonth.monthGroup = tmpObjI.monthGroup;
            var _tmpWithdrawList = [];
            for (var j = 0; j < tmpObjI.withdrawList.length; j++) {
              var tmpObjJ = tmpObjI.withdrawList[j];
              var _tmpWithdraw = {};
              _tmpWithdraw.appyId = tmpObjJ.appyId;
              _tmpWithdraw.manageId = tmpObjJ.manageId;
              _tmpWithdraw.orderId = tmpObjJ.orderId;
              _tmpWithdraw.withdrwaAmt = tmpObjJ.withdrwaAmt;
              _tmpWithdraw.reviewStatus = tmpObjJ.reviewStatus;
              _tmpWithdraw.appyTime = tmpObjJ.appyTime;
              _tmpWithdraw.reviewTime = util.formatTime2(new Date(tmpObjJ.reviewTime));
              _tmpWithdraw.reviewUser = tmpObjJ.reviewUser;
              _tmpWithdraw.reamrk = tmpObjJ.reamrk;
              _tmpWithdrawList[j] = _tmpWithdraw;
            }
            _tmpWithdrawMonth.withdrawList = _tmpWithdrawList;
            _tmpWithdrawMonthList[i] = _tmpWithdrawMonth;
          }
        }

        that.setData({
          manageTheDayProfits: e.data.manageTheDayProfits,
          manageCash: e.data.manageCash,
          profitss: _tmpProfitsMonthList,
          withdraws: _tmpWithdrawMonthList
        });
      }
    });
  }

})