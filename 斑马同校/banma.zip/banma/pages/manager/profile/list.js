// pages/manager/profile/list.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    profileList:[],
    searchValue:'',
    orderPageNum: 1, //订单当前页数
    over: true, //显示下页订单
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //this.profileList();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (this.data.profileList != null && this.data.profileList.length>0){

    }else{
      this.profileList()
    }
    
  },
  searchInput(e){
    this.setData({
      searchValue:e.detail.value
    })
  },
  onReachBottom: function () {
    if (!this.data.over) {
      this.profileList();
    }

  },
  profileList: function () {
    var that = this;
    var userName = this.data.searchValue
    userName = userName === '' ? null : userName
    util.request(api.ProfileList, {
      userName: userName,
      pageNum: this.data.orderPageNum
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        var list = res.data.userList
        var obj=null;
        for(var i=0;i<list.length;i++){
          obj=list[i];
          // obj.profile_date = util.formatTime2(obj.profile_date)
        }
        if (list.length >= 20) {
          that.setData({
            orderPageNum: that.data.orderPageNum + 1,
            over: false
          })
        } else {
          that.setData({
            over: true
          })
        }
        that.setData({
          profileList: that.data.profileList.concat(list)
        })
      }else{
        that.setData({
          over: true
        })
      }
    })
  },
  formSubmit1:function(e){
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: '/pages/manager/profile/info?id=' + e.currentTarget.dataset.id +"&extendId="+e.currentTarget.dataset.extendid,
    })
  },
  gotoDetail: function (e){
    if (e.currentTarget.dataset.type==3){
      return false;
    }
    console.log("id=" + e.currentTarget.dataset.id + "\nextendId=" + e.currentTarget.dataset.extendid);
    wx.navigateTo({
      url: '/pages/manager/profile/info?id=' + e.currentTarget.dataset.id+"&extendId="+e.currentTarget.dataset.extendid,
    })
  },
  search(){
    this.setData({
      orderPageNum:1,
      profileList:[]
    })
    this.profileList();
  }
})