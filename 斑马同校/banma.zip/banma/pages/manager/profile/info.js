
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    targetUserId:0,
    extendid:0,
    itemList: ['信息不完整', '学生证件模糊不清', '学生证件与描述信息不符'],
  },
  onLoad: function(options) {
    this.setData({
      targetUserId: options.id,
      extendid:options.extendId,
      targetUser:null,
      userInfoExtend:null,
      sysOrg:null,
    })
    this.userDetail();

  },
  revoke() {
    var that=this
    wx.showActionSheet({
      itemList: this.data.itemList,
      // itemColor: '',
      success: function(res) {
        that.profileResult(2, that.data.itemList[res.tapIndex]);
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  userDetail:function(){
    var that=this;
    util.request(api.ProfileUserDetail, 
      { 
        targetUserId: this.data.targetUserId,extendId:this.data.extendid 
      }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          targetUser: res.data.targetUser,
          userInfoExtend: res.data.userInfoExtend,
          sysOrg: res.data.sysOrg
        })
      }
    })
  },
  profileConfirm:function(){
    var that=this;
    wx.showModal({
      title: '审核提示',
      content: '确定审核通过吗？',
      success(res) {
        if (res.confirm) {
          that.profileResult(1,"您的身份认证已通过!");
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  profileResult:function(type,result){//审核结果
    var that=this;
    util.request(api.ProfileResult, { 
      targetUserId: this.data.targetUserId ,
      result:result,
      type:type
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '审核成功',
          success:function(){
            wx.navigateTo({
              url: '/pages/manager/profile/list'
            })
             /*
            wx.navigateBack({
              delta: 1
            })
            */
          }
        })
      }
    })
  },
  previewImg: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src + '', // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  }
})