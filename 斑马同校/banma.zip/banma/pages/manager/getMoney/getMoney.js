// pages/manager/getMoney/getMoney.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');


Page({

  /**
   * 页面的初始数据
   */
  data: {
    manageCash:null,
    userInfo:null,
    withdrawAmt:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo:wx.getStorageSync("userInfo")
    });
    this.index();
  },

  /**
   * 初始化加载数据
   */
  index(){
    var that=this;
    util.request(api.ManageCashs, { userId: that.data.userInfo.userId},"POST").then(function(e){
      if(e.errno==0){
        that.setData({
          manageCash: e.data.manageCash
        });
      }
    });
  },
  //提现操作
  manageWithdraw(){
    var that=this;
    if(that.data.withdrawAmt < 1){
      wx.showModal({
        title: '提示',
        content: '提现金额不能少于1元'
      })
      return false;
    }
    util.request(api.ManageWithdrawAppy, { withdrwaAmt:that.data.withdrawAmt},"POST",function(e){
      if(e.errno==0){
        wx.showModal({
          title: '提示',
          content: '已提交申请，请耐心等待审核'
        });
        wx.navigateTo({
          url: '/pages/manager/getDetail/getDetail',
        });
      }else{
        wx.showModal({
          title: '提示',
          content: '申请失败'
        })
      }
    });
  },
  withdrawAmt:function(e){
    this.setData({
      withdrawAmt:e.detail.value
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})