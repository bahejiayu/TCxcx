// pages/ucenter/bind/phone.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userName:'',
    userHeadIcon: '',
    contactMobile: '',
    apartmentName: '',
    tempId:'',
    userOrgId:'',
    userInfo:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '用户'
    })
    this.setData({
      userInfo:wx.getStorageSync("userInfo"),
      
    })
    this.setData({
      tempId: this.data.userInfo.tempId,
      userOrgId: this.data.userInfo.manageOrgId
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  userNameInput(e){
    this.setData({
      userName:e.detail.value
    })
  },
  userHeadIconInput(e) {
    this.setData({
      userHeadIcon: e.detail.value
    })
  },
  contactMobileInput(e) {
    this.setData({
      contactMobile: e.detail.value
    })
  },
  apartmentNameInput(e) {
    this.setData({
      apartmentName: e.detail.value
    })
  },
  tempIdInput(e) {
    this.setData({
      tempId: e.detail.value
    })
  },
  userOrgIdInput(e) {
    this.setData({
      userOrgId: e.detail.value
    })
  },
  newSchoolSubmit:function(){
   
    var that = this;
    var userName = this.data.userName
    var userHeadIcon = this.data.userHeadIcon
    var contactMobile = this.data.contactMobile
    var apartmentName = this.data.apartmentName
    var tempId = this.data.tempId
    var userOrgId = this.data.userOrgId
    if (userName === '' || userHeadIcon === '' || contactMobile === '' || apartmentName === "" || tempId === "" || userOrgId === ""){
      wx.showModal({
        title: '提示',
        content: '请完整填写',
      })
      return false;
    }
    util.request(api.CreateVirtualPeople, { 
      userName: userName,
      userHeadIcon: userHeadIcon,
      contactMobile: contactMobile,
      apartmentName: apartmentName,
      tempId: tempId,
      userOrgId: userOrgId
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '新增成功',
          showCancel:false,
          success:function(){
            wx.navigateBack({
              delta:1
            })
          }
        })
      }
    })
  }
})