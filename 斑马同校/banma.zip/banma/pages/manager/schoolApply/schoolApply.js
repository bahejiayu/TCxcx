const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    list: '',
    isAllCheck: false,
    checkNum: 0
  },
  submitConfirm:function(){
    var that=this
    console.log(this.data.checkNum)
    if (this.data.checkNum<=0){
      wx.showModal({
        title: '提示',
        content: '最少选择一个订单进行审核。',
        showCancel:false
      })
      return false;
    }
    wx.showModal({
      title: '提示',
      content: '确定进行审核通过吗?',
      success(res) {
        if (res.confirm) {
          that.formSubmit();

        }
      }
    })
  },
  formSubmit() {
    var that=this
    var list=this.data.list
    var obj=null;
    var idStr="";
    
    if (list != null && list.length>0){
      for(var i=0;i<list.length;i++){
        obj=list[i];
        if (obj.isCheck){
          idStr+=","+obj.record_id;
        }
      }
    }
    if (idStr!=""){
      idStr=idStr.substring(1);
    }else{
      idStr=null;
    }
    wx.showLoading({
      title: '处理中，请等待',
    })
    util.request(api.ProfileWithdrawOrder, { idStr: idStr}, "POST").then(function (res) {
      wx.hideLoading();
      if (res.errno === 0) {
        var msg="";
        if (res.data.failCount>0){
          msg="(失败原因："+res.data.msg+")";
        }
        wx.showModal({
          title: '提示',
          content: '处理完成，总共' + res.data.totalCount + "个审核订单，成功" + res.data.successCount + "个，失败" + res.data.failCount + "个" + msg,
          showCancel: false
        })
        that.withdrawOrdrerList();
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  onLoad() {
    this.list()
    
  },
  selectList(e) {
    const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
    let list = this.data.list; // 获取审核列表
    let checkNum = this.data.checkNum;
    const isCheck = list[index].isCheck; // 获取当前审核选中状态
    if (!isCheck) { // 已选数量
      checkNum++
    } else {
      checkNum--
    }
    list[index].isCheck = !isCheck; // 改变状态
    this.setData({
      list: list,
      checkNum: checkNum
    });
  },
  selectAll() {
    let isAllCheck = this.data.isAllCheck; // 是否全选状态
    isAllCheck = !isAllCheck;
    let list = this.data.list;
    if (isAllCheck) {
      this.setData({
        checkNum: list.length
      })
    } else {
      this.setData({
        checkNum: 0
      })
    }
    for (let i = 0; i < list.length; i++) {
      list[i].isCheck = isAllCheck; // 改变所有商品状态
    }
    this.setData({
      isAllCheck: isAllCheck,
      list: list
    });

  },
  list: function () {
    var that = this;
    util.request(api.SchoolApplyList, { }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        var obj = null;
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime5(new Date(obj.createDate));
          // obj.isCheck=false
        }
        that.setData({
          list: list,
        })
      }
    })
  },

})