// pages/manager/managerInfo/managerInfo.js

const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    show_list:false,
    show_module:false,
    cur_school:"暨南大学(番禺校区)",
    bindInfoId:"",
    bindInfo:null,
    schoolList:null,
    userInfo:null,
    orgId:""
  },
  get_school:function(e){
      this.setData({
        cur_school: e.target.dataset.school,
        show_list:false,
        orgId: e.target.dataset.orgid,

      });
  },
  tog_list:function(){
    var that=this;
      this.setData({
        show_list: !that.data.show_list
      });
  },
  manger_jb:function(){
    wx.showModal({
      title: '提示',
      content: '你确定要解绑“鱼丸没有鱼”吗？',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  show_mo:function(){
    this.setData({
      show_module: true
    });
  },
  close_mo:function(){
      this.setData({
        show_module:false
      });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      bindInfoId: options.bindInfoId,
      userInfo:wx.getStorageSync("userInfo")
    });
    this.findBindInfo();
    this.findSchoolList();
  },
  //查找需要绑定管理员的用户信息
  findBindInfo(){
    var that=this;
    util.request(api.AdminList, { tempId: that.data.bindInfoId }, "POST").then(function (e) {
      if (e.errno == 0) {
        that.setData({
          bindInfo: e.data[0]
        });
      }
    });
  },
  //查找学校
  findSchoolList(){
    var that = this;
    util.request(api.SchoolList2, { parentId: that.data.userInfo.manageOrgId}, "POST").then(function (e) {
      if (e.errno == 0) {
        that.setData({
          schoolList: e.data.list
        });
      }
    });
  },
  //绑定管理员
  bindAdmin(){
    var that = this;
    util.request(api.BindAdmin, 
      { 
        userId: that.data.bindInfo.userId,
        manageOrgId:that.data.orgId,
        manageOrgName: that.data.cur_school
      }, "POST").then(function (e) {
      if (e.errno == 0) {
        wx.showModal({
          title: '提示',
          content: '设置完成'
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})