// pages/manager/set/set.js

const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');

var str_data=0;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data_: [
   
      
    ],
    adminList:[],
    users:"",
    show_moddle:false,
    show_select:false,
    cur_school: "暨南大学(番禺校区)",
    orgId:'',
    unBindId:""
  },
  users:function(e){
      this.setData({
        users:e.detail.value
      });
  },
  // 点击了绑定  显示学校选择弹窗
  show_bind:function(){
      this.setData({
        show_select:true
      });
  },
  // 获取选择了哪个谢谢
  get_school: function (e) {
    console.log(e.target)
    this.setData({
      cur_school: e.target.dataset.school,
      show_list: false
    });
  },
  // 控制显示 隐藏 学校列表
  tog_list: function () {
    var that = this;
    this.setData({
      show_list: !that.data.show_list
    });
  },
  manger_jb: function () {
    wx.showModal({
      title: '提示',
      content: '你确定要解绑“鱼丸没有鱼”吗？',
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  //解绑
  unBindAdmin() {
    var that = this;
    util.request(api.UnbindAdmin, { userId: that.data.unBindId }, "POST").then(function (e) {
      if (e.errno == 0) {
        wx.showModal({
          title: '提示',
          content: '已解绑'
        });
      }
    });
  },
  // 显示选择学校弹框
  show_mo: function () {
    this.setData({
      show_select: true
    });
  },
  // 关闭选择学校弹框

  close_mo: function () {
    this.setData({
      show_select: false
    });
  },


    // 显示底部的模态框
  show_md:function(e){
    this.setData({
      unBindId: e.currentTarget.dataset.unbindid,
      show_moddle:true
    });

  },
    // 关闭底部的模态框

  cancel_module:function(){
    this.setData({
      show_moddle: false
    });
  },
  // 滑动开始
  tou_str:function(e){
    console.log(e.changedTouches[0].pageX);
    str_data = e.changedTouches[0].pageX;
  },
  // 滑动结束
  tou_end:function(e){
    var that=this;
    var index_=e.target.dataset.index;
    // console.log(e.target.dataset)
    // console.log(e.changedTouches[0].pageX);
    if (e.changedTouches[0].pageX < str_data){
      var chaData = str_data-e.changedTouches[0].pageX ;
      if (chaData>10){
        var list_ = that.data.adminList;
        list_[index_].left=true;
        console.log(list_[index_].left)
           that.setData({
             adminList: list_
           })

          }
      }else{
      var chaData = e.changedTouches[0].pageX- str_data ;
      if (chaData > 10) {
        var list_ = that.data.adminList;
        list_[index_].left = false;
        console.log(list_[index_].left)
        that.setData({
          adminList: list_
        })

      }

      }

    str_data=0;

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      userInfo:wx.getStorageSync("userInfo")
    });
    this.getAdminList();
  },
  //管理员列表
  getAdminList(){
    var that=this;
    util.request(api.AdminList,{users:that.data.users},"POST").then(function(e){
      if(e.errno==0){
        that.setData({
          adminList:e.data
        });
      }
    });
  },
  seachAdmin(){
    this.getAdminList();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})