const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    orderList:[],
    codeInput:'',
    itemList: ['进行中', '已完成', '已取消','删除'],
    orderPageNum:1,
    over:true,
    searchType:['订单类别','真实订单','虚拟订单'],
    searchIndex:0
  },
  onLoad: function (options) {
    this.orderList();
  },
  codeInput:function(e){
    this.setData({
      codeInput:e.detail.value
    })
  },
  onReachBottom: function () {
    if (!this.data.over) {
      this.orderList();
    }

  },
  selectType(e) {
    var that=this;
    var id=e.currentTarget.dataset.id;
    var code = e.currentTarget.dataset.code;
    var orderType=e.currentTarget.dataset.type;
    wx.showActionSheet({
      itemList: that.data.itemList,
      // itemColor: '',
      success: function (res) { 
        if (res.tapIndex == 0) {
          wx.showModal({
            title: '提示',
            content: '确定要将订单(' + code+')状态改为进行中？',
            success(res) {
              if (res.confirm) {
                that.authChangeOrder(id,2)
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
        else if (res.tapIndex==1){
          wx.showModal({
            title: '提示',
            content: '确定要将订单(' + code +')状态改为已完成？接单人将受到感谢费',
            success(res) {
              if (res.confirm) {
                that.authChangeOrder(id,8)
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        } 
        else if (res.tapIndex == 2) {
          wx.showModal({
            title: '提示',
            content: '确定要将订单(' + code +')状态改为已取消？感谢费将返还给接单人',
            success(res) {
              if (res.confirm) {
                that.authChangeOrder(id,4)
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }else if(res.tapIndex==3){
          if (orderType==10){
            wx.showModal({
              title: '提示',
              content: '确定要将该虚拟订单删除？',
              success(res) {
                if (res.confirm) {
                  console.log("id"+id)
                  that.delOrder(id)
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
          }else{
            wx.showModal({
              title: '提示',
              content: '正常订单不允许删除，只能删除虚拟订单。',
              showCancel:false
            })
          }
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  authChangeOrder:function(id,type){
    var that = this;
    util.request(api.AuthChangeOrder, {
      orderId: id,
      status: type,
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '订单状态修改成功！',
        })
        that.orderList()
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  delOrder: function (id) {
    var that = this;
    util.request(api.DelOrder, {
      orderId: id,
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '删除成功！',
        })
        var list = that.data.orderList;
        for(var i=0;i<list.length;i++){
          if(list[i].order_id==id){
            list[i].pay_type=100;
            break;
          }
        }
        that.setData({
          orderList: list
        })
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  orderList: function () {
    var that = this;
    var code = this.data.codeInput
    if(code==""|| code==" "){
      code=null
    }
    var searchIndex = this.data.searchIndex == 0 ? 0 : this.data.searchIndex == 1 ? 10 : 11;
    util.request(api.AllOrder2, {
      status: 100,
      pageNum: that.data.orderPageNum,
      pageSize: 20,
      orderCode: code ,
      orgId: this.data.defaultOrgId,
      pic: searchIndex
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        //解析时间 x小时前| mm-dd hh:mm
        //小于24小时86400000 
        var obj = null;
        var now = new Date().getTime();
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime3(obj.create_date);
          obj.status = util.orderStatus(obj.status);
          obj.remark = util.nto(obj.remark)
        }

        if (list.length >= 20) {
          that.setData({
            orderPageNum: that.data.orderPageNum + 1,
            over: false
          })
        } else {
          that.setData({
            over: true
          })
        }
        that.setData({
          orderList: that.data.orderList.concat(list),
        })
      } else {
        that.setData({
          over: true
        })
      }
    })
  },
  gotoDetail: function (e) {//进入详情页
    var id = e.currentTarget.dataset.id;
    var uid = e.currentTarget.dataset.uid;
    var sex = e.currentTarget.dataset.sex;
    if (uid != this.data.userId) {
      if (sex == 0) {//限制男
        // if (this.data.userSex != 0) return false;
      } else if (sex == 1) {//限制女
        // if (this.data.userSex != 1) return false;
      }
    }
    wx.navigateTo({
      url: '/pages/task/info?orderId=' + id,
    })
  },
  search(){
    this.setData({
      orderPageNum:1,
      orderList:[]
    })
    this.orderList();
  },
  //所有按钮埋点，用于推送
  formSubmit1: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    // this.search()
    // var url = e.currentTarget.dataset.url;
    // wx.navigateTo({
    //   url: "/pages/ucenter/order/order?type=0",
    // })
  },
  selectType2() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.searchType,
      success(res) {
        that.setData({
          searchIndex: res.tapIndex,
           orderPageNum: 1,
          orderList: []
        })
        that.orderList();
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
})