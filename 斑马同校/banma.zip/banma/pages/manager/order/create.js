const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
    data: {
        type: 0,
        price: 0,
        tempPrice: 2,
        time: 3,
        lowPrice: 2,
        SexList: ['不限性别', '限男生', '限女生'],
        payType: ['微信支付', '余额支付'],
        payTypeIndex:0,
        SexIndex: 0,
        showInput: false,
        addOrder:false,
        overTime: 2,
        userMobile:null,
        placeholder: '',
        statusChecked:false,
        StartTime: [
            ['最快送达时间','今天', '明天'],
            [''],
          ['00', '10', '20', '30', '40', '50']
        ],
        StartIndex: [0, 0, 0],
        EndTime: [
          ['最晚送达时间','今天', '明天'],
          [''],
          ['00', '10', '20', '30', '40', '50']
        ],
        EndIndex: [0, 0, 0],
        toggleText: false,
        photoSourceArr:[],//图片上传列表
        remarkInput:'',
        descInput:'',
        orgId:0,
        orgName:'',
        userId:0,
        x:0,
        y:0,
        poiName:'',
        name:null,
        desc:null,
        userAddress:null,
        userAddressName:null,
        userAddressDesc:null,
        userAddressDescRecord:null,
        defaultAddress:null,
        userCash:0.0,
        sendUser:[],
        sendUserList:[],
        sendUserIndex:0,
        userInfo:null,
        targetUser:[],
        targetUserList:[],
        targetUserIndex:0,
    },
    onLoad(e) {
      //type=package canteen other 0 1 2
        this.setData({
            type: e.type==undefined?0:e.type,
            price: this.data.lowPrice,
          userInfo: wx.getStorageSync("userInfo")
        })
        if(this.data.type==0){
          this.setData({
            toggleText:true,
            statusChecked:true
          })
        }
        this.setDetail();
        
        //拼装开始和结束时间格式
      var hour = new Date().getHours();
      var minute = new Date().getMinutes();
      var hourArr=[];
      var dayArr=[];
      for(var i=6;i<24;i++){
        // if (hour<=i){
          hourArr.push(i);
        // }
      }
      for(var i=2;i<=6;i++){
        var date=new Date().getTime()+1000*60*60*24*i;
        
        dayArr.push(util.formatTime2(new Date(date)));
      }
      var StartTime = this.data.StartTime
      var EndTime = this.data.EndTime
      StartTime[0] = StartTime[0].concat(dayArr);
      StartTime[1] = StartTime[1].concat(hourArr);
      EndTime[0] = EndTime[0].concat(dayArr);
      EndTime[1] = EndTime[1].concat(hourArr);
      this.setData({
        StartTime: StartTime,
        EndTime: EndTime,
      })
      wx.removeStorageSync('startPosition')
      wx.removeStorageSync('endPosition')
      this.userDefaultAddress();
    },
    onShow(){
      var orgId = wx.getStorageSync("sysOrderOrgId")
      var orgName = wx.getStorageSync("sysOrderOrgName")
      if (orgId!==""){
        this.setData({
          orgId: orgId,
          orgName: orgName,
        })
        this.userList();
      }
    },
  bindIsDefault: function () {//默认地址选取
    this.setData({
      statusChecked: !this.data.statusChecked
    })
  },
    setDetail() {
        let type = this.data.type;
        let that = this;
        this.setData({
            type: this.data.type,
        })
        if (type == 0) {
            this.setData({
                placeholder: '复制粘贴您的取件信息或上传信息截图(此处信息仅对接单人可见)',

            })
        } else {
            this.setData({
                placeholder: '跑腿内容(叫外卖、带东西等，垫付的商品费，送货时当面结清)请您务必描述清楚，便于接单人员快速为您送达'
            })

        }
    },
    showModal(e) {
        let showName = e.currentTarget.dataset.modal;
        this.setData({
            modalName: showName
        })
    },
    closeModal(e) {
        this.setData({
            modalName: null
        })
    },
    showInput() {
        this.setData({
            showInput: true
        })
    },
    inputPrice(e) {
      if (this.data.tempPrice>e.detail.value){
        return ;
      }
        this.setData({
            tempPrice: e.detail.value
        })
    },
    poiNameInput(e){
      this.setData({
        poiName: e.detail.value
      })
    },
    selectPrice(e) {
        this.setData({
            tempPrice: e.currentTarget.dataset.price
        })
    },
    finishPrice() {
      if(this.data.tempPrice!=""){
        this.setData({
          price: this.data.tempPrice,
          modalName: null
        })
      }else{
        this.setData({
          modalName: null
        })
      }
        
    },
    selectSex() {
        let that = this;
        wx.showActionSheet({
            itemList: that.data.SexList,
            success(res) {
                that.setData({
                    SexIndex: res.tapIndex
                })
            },
            fail(res) {
                console.log(res.errMsg)
            }
        })
    },
  selectPayType() {
    let that = this;
    wx.showActionSheet({
      itemList: that.data.payType,
      success(res) {
        that.setData({
          payTypeIndex: res.tapIndex
        })
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
    overTime(e) {
        this.setData({
            overTime: e.detail.value
        })
    },
  startTimeTap:function(){
    var startIndex = this.data.StartIndex
    if (startIndex[0] == 0) {
      startIndex[0] = 1
    }
    if (startIndex[1] == 0) {
      startIndex[1] = 1
    }
    this.setData({
      StartIndex: startIndex
    })
  },
  endTimeTap: function () {
    var endIndex = this.data.EndIndex
    if (endIndex[0] == 0) {
      endIndex[0] = 1
    }
    if (endIndex[1] == 0) {
      endIndex[1] = 1
    }
    this.setData({
      EndIndex: endIndex
    })
  },
    StartTime: function(e) {
     
        this.setData({
            StartIndex: e.detail.value
        })
    },
    EndTime: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            EndIndex: e.detail.value
        })
    },
    StartPlace() {
        wx.navigateTo({
            url: '/pages/release/selectPlace?type=0',
        })
    },
    EndPlace() {
        wx.navigateTo({
            url: '/pages/release/selectPlace?type=1',
        })
    },
    toggleText() {
        this.setData({
            toggleText: !this.data.toggleText
        })
    },
    choosePhoto: function () {//添加图片
      var that = this;
      wx.chooseImage({
        success: function (res) {
          var tempFilePaths = res.tempFilePaths
          wx.uploadFile({
            url: api.UploadFileSource, 
            filePath: tempFilePaths[0],
            name: 'file',
            formData: {
            },
            success: function (res) {
              var data = JSON.parse(res.data);
              var sourceId = data.data.sourceId;
              var source = [{ id: sourceId, src: tempFilePaths[0]}];
              that.setData({
                photoSourceArr: that.data.photoSourceArr.concat(source)
              })
              // console.log(that.data.photoSourceArr.length)
            }
          })
        }
      })
    },
    removePhoto:function(e){
      console.log("remove")
      var id=e.currentTarget.dataset.id;
      var photoSourceArr = this.data.photoSourceArr;
      for (var i = 0; i < photoSourceArr.length;i++){
        if (photoSourceArr[i].id==id){
          photoSourceArr.splice(i,1);
          break;
        }
      }
      this.setData({
        photoSourceArr: photoSourceArr
      })
    },
    previewImg: function (e) {
      wx.previewImage({
        current: e.currentTarget.dataset.src + '', // 当前显示图片的http链接
        urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
      })
    },
    remarkInput: function (e) {//remark输入
      this.setData({
        remarkInput: e.detail.value
      })
    },
    descInput: function (e) {//desc输入
      this.setData({
        descInput: e.detail.value
      })
    },
    bindSendPickerChange: function (e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        sendUserIndex: e.detail.value
      })
  }, 
  bindTargetPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      targetUserIndex: e.detail.value
    })
  },
    orderSubmit:function(){
      var that = this;
      //非空限制
      if (this.data.remarkInput==""){
        wx.showModal({
          title: '提示',
          content: '简述信息不能为空哦。',
          showCancel:false,
        })
        return false;
      }
      
      var orderSex = this.data.SexIndex == 0 ? 2 : this.data.SexIndex==1?0:1;//性别限制
      var payType = this.data.payTypeIndex;
  
      var orderStartDate=null
      var orderEndDate=null
      var startIndex = this.data.StartIndex;
      var endIndex = this.data.EndIndex;
      var date = new Date().getTime();
      var date2 = new Date().getTime();
      var statusChecked = this.data.statusChecked?1:0
      if (startIndex[0] == 0 || startIndex[1]==0){
        wx.showModal({
          title: '提示',
          content: '请选择最快送达时间',
          showCancel: false,
        })
        return false;
      }else{
        if (startIndex[0]==2){
          date = date + 1000 * 60 * 60 * 24
        }
        var year = new Date(date).getFullYear()
        var month = new Date(date).getMonth() + 1
        var day = new Date(date).getDate()
        var hour = startIndex[1]+5;
        //补0
        year = this.addZero(year);
        month = this.addZero(month);
        day = this.addZero(day);
        hour = this.addZero(hour);
        var minute = this.data.StartTime[2][startIndex[2]];//  startIndex[2];
        orderStartDate = year+"-"+month+"-"+day+" "+hour+":"+minute+":00";
        if (startIndex[0] >2) {
          orderStartDate = this.data.StartTime[0][startIndex[0]] + " " + hour + ":" + minute + ":00";
        }
      }
      if (endIndex[0] == 0 || endIndex[1] == 0) {
        wx.showModal({
          title: '提示',
          content: '请选择最晚送达时间',
          showCancel: false,
        })
        return false;
      }else{
        if (endIndex[0] == 2) {
          date2 = date2 + 1000 * 60 * 60 * 24
        }
        var year = new Date(date2).getFullYear()
        var month = new Date(date2).getMonth() + 1
        var day = new Date(date2).getDate()
        var hour = endIndex[1]+5;
        console.log("day:" + day)
        //补0
        year = this.addZero(year);
        month = this.addZero(month);
        day = this.addZero(day);
        hour = this.addZero(hour);
        var minute = this.data.EndTime[2][endIndex[2]];;
        orderEndDate = year + "-" + month + "-" + day + " " + hour + ":" + minute + ":00";
        if (endIndex[0] > 2) {
          orderEndDate = this.data.EndTime[0][endIndex[0]] + " " + hour + ":" + minute + ":00";
        }
      }
      if (new Date(orderStartDate.replace(/-/gi, "/")).getTime() > new Date(orderEndDate.replace(/-/gi, "/")).getTime()){
        wx.showModal({
          title: '提示',
          content: '最快送达时间不能超过最晚送达时间，请重新选择时间。',
          showCancel: false,
        })
        return false;
      }
      
      util.request(api.CreateSysOrder, {
        type:that.data.type,
        payType: 0,//0微信 1余额
        remark:that.data.remarkInput,
        orderDesc:'',
        pic: '',
        poiX:0,
        orgId: this.data.orgId,
        poiY:0,
        poiName: that.data.poiName,
        poiDesc:'',
        orderAmt:that.data.price,
        // orderSex: 0,
        orderIndate: that.data.overTime,
        sdate: orderStartDate,
        edate: orderEndDate,
        userId: that.data.sendUserList[that.data.sendUserIndex].userId,
        earnUserId: that.data.targetUserList[that.data.targetUserIndex].userId
        // orderAdvanceAmt: statusChecked
      }, "POST").then(function (res) {
        if (res.errno === 0) {
          wx.showModal({
            title: '提示',
            content: '添加订单成功',
          })
        }else{
          wx.showModal({
            title: '提示',
            content: res.errmsg,
            showCancel: false,
          })
        }
      })
    },
    userDefaultAddress:function(){
      let that = this;
      util.request(api.UserDefaultAddress, {}, "POST").then(function (res) {
        if (res.errno === 0&&res.data.userAddress!=null) {
          that.setData({
            userAddressName: res.data.userAddress.contactName + "(" + res.data.userAddress.contactMobile+")",
            userAddressDesc: res.data.userAddress.apartmentName + " " + res.data.userAddress.apartmentRoom,
            userAddress: res.data.userAddress.addressId,
            userAddressDescRecord: res.data.userAddress.apartmentName,
          })
        }
      })
    },
    addZero: function (time) {//时间位补0
      return time >= 10 ? time : "0" + time;
    },
  bindMobilePage:function(){
    wx.navigateTo({
      url: '/pages/ucenter/bind/phone',
    })
  },
  userList:function(){
    let that = this;
    util.request(api.UserList, { tempId: this.data.orgId,status:11}, "POST").then(function (res) {
      if (res.errno === 0 ) {
        var list=res.data.list;
        var newArr=[]
        for(var i=0;i<list.length;i++){
          var obj=list[i];
          newArr.push(obj.userName)
        }
        that.setData({
          sendUser: newArr,
          sendUserList:res.data.list,
          targetUser: newArr,
          targetUserList: res.data.list
        })
      }else if(res.errno===501){
        wx.redirectTo({
          url: '/pages/ucenter/home/home',
        })
      }
    })
  },
  backPage() {//订单提交成功提示
    let that = this;
    if (this.data.time == 0) {
      console.log("return")
      wx.switchTab({
        url: '/pages/home/home',
        complete:function(res){
          console.log(res)
        }
      })
    } else {
      setTimeout(function () {
        that.setData({
          time: that.data.time - 1
        })
        that.backPage();
      }, 1000)
    }
  },
  //所有按钮埋点，用于推送
  formSubmit1: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    this.bindMobilePage();
  },
  formSubmit2: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    this.orderSubmit();
  },
  selectOrg() {//跳转到选择学校页面
    wx.navigateTo({
      url: '/pages/home/choose?type=5&searchValue=' + this.data.userInfo.manageOrgName,
    })
  }, 
});