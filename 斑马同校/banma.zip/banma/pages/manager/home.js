// pages/manager/home.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:null,
    allUser:0,
    todayUser:0,
    allOrder:0,
    todayOrder:0,
    permissions:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: wx.getStorageSync("userInfo")
    })
    this.indexData();
    this.managePermissions();
  },
  go_SetMan:function(e){
        wx.navigateTo({
          url: e.target.dataset.url,
        })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  managePermissions(){
    var that=this;
    util.request(api.Permissions, {userId:that.data.userInfo.userId}, "POST").then(function (res) {
      if (res.errno === 0) {
        console.log(res.data)
        that.setData({
          permissions:res.data
        });
      }
    });
  },
  go_page(e){
    var status=e.currentTarget.dataset.status;
    if(status=="N"){
      wx.showModal({
        title: '提示',
        content: '模块被禁用',
      });
    }else{
      var url = e.currentTarget.dataset.url;
      wx.navigateTo({ url:url});
    }
  },
  indexData:function(){
    var that = this;
    util.request(api.ManageIndex, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          // allUser:obj.
          allUser: obj.allUser,
          countAllOrder: obj.countAllOrder,
          countTodayOrder: obj.countTodayOrder,
          todayUser: obj.todayUser,
        })
      }else{
        wx.showModal({
          title: '提示',
          content: '您不是学校管理员',
        })
      }
    })
  },
  //所有按钮埋点，用于推送
  formSubmit1: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: "/pages/manager/profile/list",
    })
  },
  formSubmit2: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    wx.navigateTo({
      url: "/pages/manager/order/list",
    })
  },
  formSubmit3: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    wx.navigateTo({
      url: "/pages/manager/cash/cash",
    })
  },
  formSubmit4: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    wx.navigateTo({
      url: "/pages/manager/order/create",
    })
  },
  formSubmit5: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    wx.navigateTo({
      url: "/pages/manager/schoolApply/schoolApply",
    })
  },
  formSubmit6: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, { formId: formId }, "POST").then(function (res) {
      if (res.errno === 0) {
      }
    })
    wx.navigateTo({
      url: "/pages/manager/cooperation/cooperation",
    })
  },
})