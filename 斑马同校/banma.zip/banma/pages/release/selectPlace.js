// map.js
const util = require('../../utils/util.js');
const api = require('../../config/api.js');
const QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({
    data: {
        showType: 0,
        type:0,//0起始地点 1送达地点,
      addressList:[],
      longitude:0,
      latitude:0,
      markers:[],
      mapKeyWork:'快递',
      searchAddress:'',
      historyAddress:[],
      noAddress:false,
    },
    onLoad:function(options){
      var that=this;
      this.setData({
        type:options.type==undefined?0:options.type

      })
      console.log(this.data.type)
      // 实例化API核心类
      qqmapsdk = new QQMapWX({
        key: 'PIUBZ-RPRR3-NHZ33-32B6A-2J4ME-O7FHN'
      });
      wx.getLocation({
        type: 'gcj02',
        success(res) {
          that.setData({
            longitude: res.longitude,
            latitude: res.latitude
          })
        }
      })
    },
    onShow:function(){
      var that=this;
      this.getAddressList();
      this.mapSearch();
    },
    searchAddressInput:function(e){
      console.log(e.detail.value === "")
      if (e.detail.value === "") {
        this.setData({
          mapKeyWork: '快递'
        })
        this.mapSearch();
      }else{
        this.setData({
          searchAddress: e.detail.value,
          mapKeyWork: e.detail.value,
        })
        this.mapSearch();
      }
    },
    addressSubmit:function(){
      var name = this.data.searchAddress;
      if (name==""||name===""||name==null){
        return false;
      }
      var historyAddress = wx.getStorageSync("historyAddress");
      if (historyAddress===""){
        historyAddress=[]
      }
      var x = 0;
      var y = 0;
      
      var desc = "null";
      if (this.data.type == 0) {
        wx.setStorageSync('startPosition', x + "||" + y + "||" + name + "||" + desc);
        historyAddress=historyAddress.concat({
          x:0,
          y:0,
          name:name,
          desc:desc
        })
        wx.setStorageSync("historyAddress", historyAddress)
      } else {
        wx.setStorageSync('endPosition', x + "||" + y + "||" + name + "||" + desc);
      }

      wx.navigateBack({
        delta: 1
      })
    },
    mapSearch:function(){
      var that=this
      // 调用接口
      qqmapsdk.search({
        keyword: this.data.mapKeyWork,
        success: function (res) {
          console.log(res);
          var markers = []
          var obj = null
          if(res.data!=null&&res.data.length>0){
            for (var i = 0; i < res.data.length; i++) {
              obj = res.data[i];
              markers.push({
                id: obj.id,
                title: obj.title,
                address: obj.address,
                latitude: obj.location.lat,
                longitude: obj.location.lng
              })
            }
            that.setData({
              markers: markers
            })
          }else{
            that.setData({
              noAddress:true,
              markers:[]
            })
          }
        },
        fail: function (res) {
          console.log(res);
        },
        complete: function (res) {
          // console.log(res);
        }
      })
    },
    switchTab: function(event) {
        let showType = event.currentTarget.dataset.index;
        this.setData({
            showType: showType
        });
      if (showType==1){
        var historyAddress = wx.getStorageSync("historyAddress");
        if (historyAddress === "") {
          historyAddress = []
        }else{
          historyAddress = historyAddress.reverse()
        }
        this.setData({
          historyAddress: historyAddress
        })
      }
    },
    chooseUsualAddress:function(e){
      var historyAddress = wx.getStorageSync("historyAddress");
      if (historyAddress === "") {
        historyAddress = []
      }
      var x=e.currentTarget.dataset.x;
      var y = e.currentTarget.dataset.y;
      var name = e.currentTarget.dataset.name;
      var desc = e.currentTarget.dataset.desc;
      if(this.data.type==0){
        wx.setStorageSync('startPosition', x + "||" + y + "||" + name + "||" + desc);
       
        for(var i=0;i<historyAddress.length;i++){
          var obj=historyAddress[i];
          if(obj.name==name){
            historyAddress.splice(i, 1);
            break;
          }
        }
        historyAddress = historyAddress.concat({
          x: 0,
          y: 0,
          name: name,
          desc: desc
        })
        if (e.currentTarget.dataset.z==1){
          wx.setStorageSync("historyAddress", historyAddress)
        }
        
      }else{
        wx.setStorageSync('endPosition', x + "||" + y + "||" + name + "||" + desc);
      }
      
      wx.navigateBack({
        delta:1
      })
    },
  addAddress:function(){
    wx.navigateTo({
      url: '/pages/ucenter/address/add'
    })
  },
  userAddress: function (event){
    var id = event.currentTarget.dataset.addressId
    var obj = event.currentTarget.dataset.obj
    var name = obj.contactName + "(" + obj.contactMobile+")";
    var desc = obj.apartmentName + " " + obj.apartmentRoom;
    if(this.data.type==0){
      wx.setStorageSync('startPosition', id + "||" + name + "||" + desc);
    }else{
      wx.setStorageSync('endPosition', id + "||" + name + "||" + desc);
    }
    wx.navigateBack({
      delta: 1
    })
  },
  getAddressList() {
    let that = this;
    util.request(api.AddressList, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          addressList: res.data.list
        })
      }
    })
  },
  addressAddOrUpdate(event) {
    wx.navigateTo({
      url: '/pages/ucenter/address/add?addressId=' + event.currentTarget.dataset.addressId
    })
  },
  // userAddress:function(e){
  //   var id = event.currentTarget.dataset.addressId
  // }
})