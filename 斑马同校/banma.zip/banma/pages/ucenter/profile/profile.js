// pages/ucenter/profile/profile.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orgList:[],
    userInfo:null,
    userInfoExtend:null,
    tempSchool:null,//发单学校
    userOrgName:null,//接单学校
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getIndexData();
    
  },
  onShow:function(){
    // updateOrg
    var that=this;
    var id = wx.getStorageSync("updateOrg");
    var name = wx.getStorageSync("updateOrgName");
    if(name!==""){
      wx.showModal({
        title: '提示',
        content: '确定要修改发单学校为'+name+"吗？",
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            that.updateTempSchool(id);
            that.setData({
              tempSchool: name
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      wx.removeStorageSync("updateOrg");
      wx.removeStorageSync("updateOrgName");
    }
  },
  getIndexData: function () {
    var that = this;
    util.request(api.GetUserData, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        var tempId = res.data.userInfo.tempId;
        var userOrgName=null;
        var userOrgId=null
        if (res.data.userInfoExtend!=null){
          userOrgId = res.data.userInfoExtend.userOrgId
        }
        that.setData({
            userInfo: res.data.userInfo,
            userInfoExtend: res.data.userInfoExtend
        })
        if (tempId!=null){
          that.orgList(tempId,0);
          
        }
        if (userOrgId != null) {
          that.orgList(userOrgId,1);
         
        }
        
      }
    })
  },
  orgList:function(id,type){
    var that = this;
    var list = this.data.orgList
    if (list!=null&&list.length>0){
      for (var i = 0; i < list.length; i++) {
        if (list[i].orgId == id) {
          if (type == 0) {
            that.setData({
              tempSchool: list[i].orgName
            })
          } else {
            that.setData({
              userOrgName: list[i].orgName
            })
          }
          return false;
        }
      }
      return false;
    }
    util.request(api.SchoolList2, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        if(list!=null&&list.length>0){
          for(var i=0;i<list.length;i++){
            if(list[i].orgId==id){
              if(type==0){
                that.setData({
                  tempSchool: list[i].orgName
                })
              }else{
                that.setData({
                  userOrgName: list[i].orgName
                })
              }
              return false;
            }
          }
        }
      }
    })
    // return "";
  },
  updateTempSchool:function(id) {
    var that = this;
    util.request(api.UpdateTempSchool, { id: id }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.showModal({
          title: '提示',
          content: '发单学校已修改，现在您可以把单发到新学校。',
        })
      }
    })
  },
  editSchool:function(){
    wx.navigateTo({
      url: '/pages/home/choose?type=3',
    })
  },
  gotoPage: function () {
    wx.navigateTo({
      url: '/pages/ucenter/auth/name',
    })
  },
  gotoBindMobile:function(){
    if (this.data.userInfo.userMobile != null){
      wx.navigateTo({
        url: '/pages/ucenter/Untying/phone',
      })
    }else{
      wx.navigateTo({
        url: '/pages/ucenter/bind/phone',
      })
    }
   
  }
})