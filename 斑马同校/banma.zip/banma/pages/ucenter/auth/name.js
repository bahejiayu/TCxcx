const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
var mobile = wx.getStorageSync("userMobile");
Page({
  data: {
    appUrl: 'https://banma.laoyeshow.cn/sfimage/app',
    step: 0,
    time: 3,
    validCodeTime:60,
    userId:0,
    realName:null,
    userOrgId:0,
    userIdNo:null,
    userCardIcon:null,
    userSex:0,//0男1女
    userSexFlag:true,
    orgList:[],
    orgId:null,
    orgName:'',
    userMobile:null,
    validCode:null,
    validCodeFlag:true,
    parentId:2,
    schoolChooseType:2,
    tog_reshow:true,
    //isTouch:false
  },
  tog_reshow:function(){
      this.setData({
        tog_reshow: false,
      })

  },
  onLoad:function(){
    this.orgList();
    this.setData({
      userMobile: mobile
    })
    this.checkUserExtend();//检查是否有未审核的认证
  },
  onShow: function () {
    if (this.data.parentId==2){
      var id = wx.getStorageSync("authOrgId");
      if (id != undefined && id !== "") {
        this.replaceOrg(id);
      }
    }else{
      var orgId = wx.getStorageSync("defaultOrg");
      var orgName = wx.getStorageSync("defaultOrgName");
      this.setData({
        orgId: orgId,
        orgName: orgName
      })
    }
  },
  NextStep(e) {
    //保存审核内容
    var type=e.currentTarget.dataset.type
    var that = this;
    var realName = this.data.realName 
    var userOrgId = this.data.orgId 
    var userIdNo = this.data.userIdNo 
    var userCardIcon = this.data.userCardIcon 
    var userSex = this.data.userSexFlag?0:1
    if (realName == "" || realName==null){
      wx.showModal({
        title: '提示',
        content: '请填写您的真实姓名',
      })
      return false;
    }
    if (userOrgId == null) {
      wx.showModal({
        title: '提示',
        content: '请选择您的就读学校',
      })
      return false;
    }
    if (userIdNo == "" || userIdNo == null) {
      wx.showModal({
        title: '提示',
        content: '请填写您的学生证号',
      })
      return false;
    }
    if (userCardIcon == "" || userCardIcon == null) {
      wx.showModal({
        title: '提示',
        content: '请上传您的学生证照片',
      })
      return false;
    }

    util.request(api.UserAuthorizer, {
      realName: realName,
      userOrgId: userOrgId,
      userIdNo: userIdNo,
      userCardIcon: userCardIcon,
      userSex: userSex,
      type:type==0?null:3
    }, "POST").then(function (res) {
      if (res.errno != 0) {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
        return false;
      }
      if (type == 1) {
        that.setData({
          step: 2
        })
        that.backPage();
        return false;
      }
      that.setData({
        step: 1,
        orgList: null,
        orgId: null,
        orgName: '',
        parentId: null,
        schoolChooseType: 0
      })
      that.orgList()
    })

  },
  bindMobile() {
    /*
    this.setData({
      isTouch:true
    })
    */
    var that = this;
    var mobile = this.data.userMobile;
    var validCode = this.data.validCode
    if (validCode == ""||validCode==null) {
      wx.showModal({
        title: '提示',
        content: '请输入短信验证码',
      })
      return false;
    }
    if (mobile == ""||mobile==null) {
      wx.showModal({
        title: '提示',
        content: '请输入您的手机号',
      })
      return false;
    }
    if (mobile.length != 11) {
      wx.showModal({
        title: '提示',
        content: '请输入11位电话号码',
      })
      return false;
    }
    if (isNaN(mobile)) {
      wx.showModal({
        title: '提示',
        content: '请填写正确的11位手机号码',
      })
      return false;
    }
    /**
    if (this.data.orgId == null) {
      wx.showModal({
        title: '提示',
        content: '请选择您的单要发到哪个学校',
      })
      return false;
    }
     */
    util.request(api.BindMobile, { mobile: mobile, code: validCode, tempId: this.data.orgId, type: 1 }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          //isTouch:false,
          step: 2
        })
        that.backPage();
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
        return false;
      }
    })
  },
  backPage() {
    let that = this;
    if (this.data.time == 0) {
      // wx.navigateBack({
      //   delta: 1,
      // })
      wx.setStorageSync("userAuth", "true");
      wx.switchTab({
        url: '/pages/ucenter/home/home',
      })
    } else{
      setTimeout(function () {
        console.log(that.data.time);
        that.setData({
          time: that.data.time - 1
        })
        that.backPage();
      }, 1000)
    }
  },
  validCodeTimer:function(){
    let that = this;
    if (this.data.validCodeTime==0){
      this.setData({
        validCodeFlag:true,
        validCodeTime:10
      })
    }else{
      setTimeout(function () {
        that.setData({
          validCodeTime: that.data.validCodeTime - 1
        })
        that.validCodeTimer();
      }, 1000)
    }
  },
  orgList: function () {
    var that = this;
    util.request(api.SchoolList, { parentId: null}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        that.setData({
          orgList: list,
        })
      }
    })
  },
  checkUserExtend:function(){
    var that = this;
    util.request(api.GetUserInfoExtend, { }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        if(list!=null&&list.length>0){
          that.setData({
            step: 1,
            orgList: null,
            orgId: null,
            orgName: '',
            parentId: null,
            schoolChooseType: 0
          })
        }
      }
    })
  },
  replaceOrg: function (id) {
    var orgList = this.data.orgList;
    var obj = null;
    for (var i = 0; i < orgList.length; i++) {
      obj = orgList[i];
      if (obj.orgId == id) {
        this.setData({
          orgId: obj.orgId,
          orgName: obj.orgName
        })
      }
    }
  },
  selectOrg() {//跳转到选择学校页面
    wx.navigateTo({
      url: '/pages/home/choose?type=' + this.data.schoolChooseType//+'&selectType=' + this.data.parentId,
    })
  },
  //文本输入
  realNameInput: function (e) {
    this.setData({
      realName: e.detail.value
    })
  },
  idInput: function (e) {
    this.setData({
      userIdNo: e.detail.value
    })
  },
  userMobileInput: function (e) {
    this.setData({
      userMobile: e.detail.value
    })
  },
  validCodeInput: function (e) {
    this.setData({
      validCode: e.detail.value
    })
  },
  sexSelected:function(){
    this.setData({
      userSexFlag: !this.data.userSexFlag
    })
  },
  choosePhoto: function () {//添加图片
    var that = this;
    wx.chooseImage({
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        wx.uploadFile({
          url: api.UploadFile,
          filePath: tempFilePaths[0],
          name: 'file',
          formData: {
          },
          success: function (res) {
            
            var data = JSON.parse(res.data);
            var imgPath = "https://banma.laoyeshow.cn/imgFile/" + data.data.fileName;
            that.setData({
              userCardIcon: imgPath
            })
          }
        })
      }
    })
  },
  previewImg: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src + '', // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  },
  sendSms: function () {//发送验证码
    if (!this.data.validCodeFlag) {
      return false;
    }
    var that = this;
    var mobile = this.data.userMobile;
    if(mobile==""||mobile==null){
      wx.showModal({
        title: '提示',
        content: '请输入您的手机号',
      })
      return false;
    }
    if (mobile.length != 11) {
      wx.showModal({
        title: '提示',
        content: '请输入11位电话号码',
      })
      return false;
    }
    if (isNaN(mobile)) {
      wx.showModal({
        title: '提示',
        content: '请填写正确的11位手机号码',
      })
      return false;
    }
    util.request(api.SendSms, { mobile:this.data.userMobile}, "POST").then(function (res) {
      if (res.errno === 0) {
        console.log("已发送短信，请注意查收。")
        that.setData({
          validCodeFlag: false
        })
        that.validCodeTimer();
      }
    })
  },
  gotoDisclaimer() {//跳转到选择学校页面
    wx.navigateTo({
      url: '/pages/ucenter/disclaimer/disclaimer',
    })
  },
})