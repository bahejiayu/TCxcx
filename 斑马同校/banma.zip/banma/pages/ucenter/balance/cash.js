// pages/ucenter/balance/cash.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    amtInput:'',
    withdrawAmt:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      withdrawAmt: wx.getStorageSync("withdraw_amt")
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  withdrawsSubmit:function(){//提现
    var amtInput = this.data.amtInput
    if(amtInput=='' || amtInput<=0){
      wx.showModal({
        title: '提示',
        content: '请填写提现金额',
      })
    }
    if (amtInput<1){
      wx.showModal({
        title: '提示',
        content: '提现金额不能小于1元',
      })
      return false;
    }
    if (amtInput.indexOf(".")>=0){
      wx.showModal({
        title: '提示',
        content: '提现金额只能是整数。',
      })
      return false;
    }
    if (amtInput > this.data.withdrawAmt){
      wx.showModal({
        title: '提示',
        content: '提现金额不能超出当前余额',
      })
      return false;
    }
    var that = this;
    wx.showLoading();
    util.request(api.WithdrawMoney, { money: amtInput}, "POST").then(function (res) {
      wx.hideLoading()
      if (res.errno === 0) {
        that.setData({
          withdrawAmt: that.data.withdrawAmt-amtInput
        })
        wx.showModal({
          title: '提示',
          content: '申请提现成功，金额会在1到3个工作日内直接提现到您的微信零钱，请注意查收',
          showCancel:false,
          success(res) {
            if (res.confirm) {
              wx.navigateBack({
                delta: 1
              })
            } else if (res.cancel) {
              wx.navigateBack({
                delta: 1
              })
            }
          }
        })
      }else{
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  amtInput: function (e) {
    this.setData({
      amtInput: e.detail.value
    })
  },
})