const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  data: {
    list: []
  },
  onLoad(e) {
    if (e.type) {
      this.setData({
        type: e.type
      })
    }
  },
  onShow() {
    
    if (this.data.type == 0) {
      this.rechargeList()
      // this.setData({
      //   list: [{
      //     title: '微信支付（充值）',
      //     time: '2018.08.31',
      //     month: '2018.08',
      //     type: 'in',
      //     num: '25.00'
      //   }, {
      //     title: '银行卡（充值）',
      //     time: '2018.08.31',
      //     month: '',
      //     type: 'in',
      //     num: '26.00'
      //   }, {
      //     title: '微信支付（充值）',
      //     time: '2018.07.30',
      //     month: '2018.07',
      //     type: 'in',
      //     num: '25.00'
      //   }, {
      //     title: '银行卡（充值）',
      //     time: '2018.07.30',
      //     month: '',
      //     type: 'in',
      //     num: '26.00'
      //   }]
      // })
    }
    if (this.data.type == 1) {
      this.withdrawList()
      // this.setData({
      //   list: [{
      //     title: '赏金提现',
      //     time: '2018.08.31',
      //     month: '2018.08',
      //     type: 'out',
      //     num: '25.00'
      //   }, {
      //     title: '赏金提现',
      //     time: '2018.08.31',
      //     month: '',
      //     type: 'out',
      //     num: '26.00'
      //   }, {
      //     title: '赏金提现',
      //     time: '2018.07.30',
      //     month: '2018.07',
      //     type: 'out',
      //     num: '25.00'
      //   }, {
      //     title: '赏金提现',
      //     time: '2018.07.30',
      //     month: '',
      //     type: 'out',
      //     num: '26.00'
      //   }]
      // })
    }
    if (this.data.type == 2) {
      this.earnOrderList();
    }
    if (this.data.type == 3) {
      this.consumeList();
    }
  },
  rechargeList:function(){//type==0 余额充值明细
    var that = this;
    util.request(api.RechargeList, { }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list=that.data.list
        var resultList = res.data.list;
        var obj=null;
        for(var i=0;i<resultList.length;i++){
          obj=resultList[i];
          list.push({
            title: '微信支付（充值）',
            time: util.formatTime5(new Date(obj.createDate)),
            // month: util.formatTime6(new Date(obj.createDate)),
            month:'',
            type: 'in',
            num: obj.orderAmt
          })
        }
        that.setData({
          list: list,
        })
      }
    })
  },
  withdrawList: function () {//type==1 提现明细
    var that = this;
    util.request(api.WithdrawList, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = that.data.list
        var resultList = res.data.list;
        var obj = null;
        for (var i = 0; i < resultList.length; i++) {
          obj = resultList[i];
          list.push({
            title: '感谢费提现',
            time: util.formatTime5(new Date(obj.createDate)),
            // month: util.formatTime6(new Date(obj.createDate)),
            month: '',
            type: 'in',
            num: obj.amt,
            status:obj.status,
            withdraw:true
          })
        }
        that.setData({
          list: list,
        })
      }
    })
  },
  earnOrderList: function () {//type==2 赏金明细
    var that = this;
    util.request(api.EarnOrderList, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = that.data.list
        var resultList = res.data.list;
        var obj = null;
        for (var i = 0; i < resultList.length; i++) {
          obj = resultList[i];
          var typeStr = obj.type == 0 ? '快递' : obj.type == 1 ?'代购':'其他';
          list.push({
            title: '抢单跑腿(' + typeStr+")",
            time: util.formatTime5(new Date(obj.createDate)),
            // month: util.formatTime6(new Date(obj.createDate)),
            month: '',
            type: 'in',
            num: obj.orderAmt
          })
        }
        that.setData({
          list: list,
        })
      }
    })
  },
  consumeList: function () {//type==3 消费明细
    var that = this;
    util.request(api.ConsumeList, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = that.data.list
        var resultList = res.data.list;
        var obj = null;
        for (var i = 0; i < resultList.length; i++) {
          obj = resultList[i];
          var typeStr = obj.type == 0 ? '快递' : obj.type == 1 ? '代购' : '其他';
          list.push({
            title: '发布跑腿(' + typeStr + ")",
            time: util.formatTime5(new Date(obj.createDate)),
            // month: util.formatTime6(new Date(obj.createDate)),
            month: '',
            type: 'out',
            num: obj.orderAmt
          })
        }
        that.setData({
          list: list,
        })
      }
    })
  },
})