// pages/ucenter/balance/recharge.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    rechargeValue:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  rechargeValueInput:function(e){
    this.setData({
      rechargeValue: e.detail.value
    })
  },
  rechargeSubmit:function(){
    var rechargeValue = this.data.rechargeValue
    if(rechargeValue=="" ||rechargeValue==null){
      wx.showModal({
        title: '提示',
        content: '请输入要充值的金额',
      })
      return false;
    }
    if (rechargeValue<2){
      wx.showModal({
        title: '提示',
        content: '充值金额不能少于2元',
      })
      return false;
    }
    if (rechargeValue.indexOf(".")>=0){
      wx.showModal({
        title: '提示',
        content: '充值金额只能是整数',
      })
      return false;
    }

    var that=this
    util.request(api.PayRecharge, {
      orderAmt: rechargeValue
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.requestPayment({
          'timeStamp': res.data[0].timeStamp,
          'nonceStr': res.data[0].nonceStr,
          'package': res.data[0].package,
          'signType': 'MD5',
          'paySign': res.data[0].paySign,
          'success': function (res) {
            wx.showModal({
              title: '提示',
              content: '充值成功！',
              success(res) {
                wx.navigateBack({
                  delta: 1
                })
              }
            })
            
          },
          'fail': function (res) {
            console.log("cancel pay");
          }
        })
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  }
})