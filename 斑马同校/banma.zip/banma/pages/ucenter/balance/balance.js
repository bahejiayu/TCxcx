const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    userCash:null,
    consumeAmt:0.0,
    earnAmt:0.0
  },
  onShow:function(){
    this.getUserCash();
  },
  showDetail() {
    wx.showActionSheet({
      itemList: ['余额充值明细', '提现明细', '感谢费记录', '消费记录'],
      success: function(res) {
        wx.navigateTo({
          url: '/pages/ucenter/balance/detail?type=' + res.tapIndex,
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  getUserCash:function(){
    var that = this;
    util.request(api.GetUserCash, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          userCash: res.data.userCash,
          consumeAmt: res.data.amt == null ? 0 : res.data.amt,
          earnAmt: res.data.earnAmt == null ? 0 : res.data.earnAmt,
        })
      }
    })
  },
  gotoPage:function(e){
    wx.setStorageSync("withdraw_amt", this.data.userCash.amt);
    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  },
})