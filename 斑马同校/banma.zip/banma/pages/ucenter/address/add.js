// pages/ucenter/address/add.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    defaultOrgId:null,
    defaultOrgName:'',
    orgId:null,
    orgName:'',
    orgList: [],
    orgIndex:0,//选中的学校,
    contactName:'',
    contactMobile:'',
    status:0,//0非默认 1默认
    statusChecked:false,
    apartmentName:'',
    apartmentRoom:'',
    addressId:null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.setData({
    //   orgId: this.data.defaultOrgId,
    //   orgName: this.data.defaultOrgName,
    // })
    var wxName=wx.getStorageSync("wxName")
    var wxMobile =wx.getStorageSync("wxMobile")
    var wxAddress =wx.getStorageSync("wxAddress")
    if (wxName!==""){
      wx.removeStorageSync("wxName");
      wx.removeStorageSync("wxMobile");
      wx.removeStorageSync("wxAddress");
      this.setData({
        apartmentName: wxAddress,
        contactName: wxName,
        contactMobile: wxMobile
      })
    }
    if (options.addressId!=undefined){
      this.setData({
        addressId:options.addressId
      })
      this.addressDetail();
    }
    
  },
  onShow:function(){
    this.getUserData()
    var id = wx.getStorageSync("tempId");
    var name = wx.getStorageSync("addressOrgName");
    // wx.setStorageSync("addressOrg", e.currentTarget.dataset.id);
    // wx.setStorageSync("addressOrgName", e.currentTarget.dataset.name);
    if (id!==""){
      this.setData({
        orgId: id,
        orgName: name
      })
    }
  },
  getUserData: function () {
    var that = this;
    util.request(api.GetUserNew, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        if (obj.userInfo.tempId!=null){
          that.orgList(obj.userInfo.tempId);
        }
      }
    })
  },
  orgList: function (id) {
    var that = this;
    util.request(api.SchoolList, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        for(var i=0;i<list.length;i++){
          if(list[i].orgId==id){
            that.setData({
              orgId: list[i].orgId,
              orgName: list[i].orgName
            })
          }
        }
        
      }
    })
  },
  addressDetail: function() {
    var that = this;
    util.request(api.AddressDetail, { id: this.data.addressId}, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          orgId: res.data.userAddress.orgId,
          apartmentName: res.data.userAddress.apartmentName,
          apartmentRoom: res.data.userAddress.apartmentRoom,
          contactMobile: res.data.userAddress.contactMobile,
          contactName: res.data.userAddress.contactName,
          statusChecked: res.data.userAddress.status==1?true:false,
        })
        that.replaceOrg(res.data.userAddress.orgId);
        // orgId: 0,
        //   orgName: '清华大学',
        //     orgList: [],
        //       orgIndex: 0,//选中的学校,
        //         contactName: '',
        //           contactMobile: '',
        //             status: 0,//0非默认 1默认
        //               statusChecked: false,
        //                 apartmentName: '',
        //                   apartmentRoom: '',
      }
    })
  },
  selectOrg() {//跳转到选择学校页面
    wx.navigateTo({
      url: '/pages/home/choose?type=1',
    })
  },
  addressSubmit: function () {
    var orgId=this.data.orgId;
    var status = this.data.statusChecked?1:0;
    var contactName = this.data.contactName;
    var contactMobile = this.data.contactMobile;
    var apartmentName = this.data.apartmentName;
    var apartmentRoom = this.data.apartmentRoom;
    if (orgId == null || orgId===""){
      orgId=0;
    }
    if (contactName==""){
      wx.showModal({
        title: '提示',
        content: '请填写联系人姓名哦。',
        showCancel: false,
      })
      return false;
    }
    if (contactMobile == "") {
      wx.showModal({
        title: '提示',
        content: '请填写联系人手机哦。',
      })
      return false;
    }
    if (contactMobile.length!=11) {
      wx.showModal({
        title: '提示',
        content: '请填写正确的11位手机号哦。',
        showCancel: false,
      })
      return false;
    }
    if (apartmentName == "") {
      wx.showModal({
        title: '提示',
        content: '请填写楼名哦。',
        showCancel: false,
      })
      return false;
    }
    var that = this;
    util.request(api.AddAddress, {
      contactMobile:contactMobile,
      contactName:contactName,
      apartmentName: apartmentName,
      apartmentRoom: apartmentRoom,
      orgId: orgId,
      status:status,
      addressId:this.data.addressId
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.setStorageSync("addAddress", "1");
        wx.navigateBack({
          delta: 1
        })
      }
    })
  },
  bindIsDefault:function(){//默认地址选取
    this.setData({
      statusChecked: !this.data.statusChecked
    })
  },
  //文本输入
  contactNameInput: function (e) {
    this.setData({
      contactName: e.detail.value
    })
  },
  contactMobileInput: function (e) {
    this.setData({
      contactMobile: e.detail.value
    })
  },
  apartmentNameInput: function (e) {
    this.setData({
      apartmentName: e.detail.value
    })
  },
  apartmentRoomInput: function (e) {
    this.setData({
      apartmentRoom: e.detail.value
    })
  },
  replaceOrg:function(id){
    var orgList = this.data.orgList;
    var obj=null;
    for(var i=0;i<orgList.length;i++){
      obj=orgList[i];
      if(obj.orgId==id){
        this.setData({
          orgId:obj.orgId,
          orgName:obj.orgName
        })
      }
    }
  }

})