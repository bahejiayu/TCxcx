const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    addressList: [],
    address: {
      id: 0,
      provinceId: 0,
      cityId: 0,
      areaId: 0,
      address: '',
      name: '',
      mobile: '',
      isDefault: 0,
      provinceName: '',
      cityName: '',
      areaName: '',
      region: ''
    },
  },
  onShow: function () {
    this.getAddressList();
  },
  toAdd() {
    wx.navigateTo({
      url: 'add'
    })
  },
  getAddressList() {
    let that = this;
    util.request(api.AddressList, {  }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          addressList: res.data.list
        })
      }
    })
    // that.setData({
    //   "addressList": [
    //     {
    //       "isDefault": false,
    //       "detailedAddress": "广东省广州市荔湾区菊树水口坊130号（鸿达公寓）",
    //       "name": "文港",
    //       "mobile": "17373728521",
    //       "id": 15
    //     },
    //     {
    //       "isDefault": false,
    //       "detailedAddress": "广东省广州市海珠区赤岗红卫新村",
    //       "name": "文晓港",
    //       "mobile": "18613048521",
    //       "id": 16
    //     },
    //     {
    //       "isDefault": true,
    //       "detailedAddress": "广东省广州市海珠区红卫新村西街",
    //       "name": "文晓港",
    //       "mobile": "18613048521",
    //       "id": 17
    //     }
    //   ],
    // });
  },
  addressAddOrUpdate(event) {
    wx.navigateTo({
      url: '/pages/ucenter/address/add?addressId=' + event.currentTarget.dataset.addressId
    })
  },
  newAddress:function(){
    wx.navigateTo({
      url: '/pages/ucenter/address/add'
    })
  },
  deleteAddress(event) {
    console.log(event.currentTarget)
    let that = this;
    wx.showModal({
      title: '',
      content: '确定要删除地址？',
      success: function (res) {
        if (res.confirm) {
          let addressId = event.currentTarget.dataset.addressId;
          that.deleteSubmit(addressId);
       
          console.log('用户点击确定')
        }
      }
    })
    return false;

  },
  deleteSubmit:function(id){
    var that = this;
    util.request(api.DelAddress, {id:id}, "POST").then(function (res) {
      if (res.errno === 0) {
        var addressList = that.data.addressList;
        var obj=null;
        for(var i=0;i<addressList.length;i++){
          obj=addressList[i];
          if(obj.addressId==id){
            addressList.splice(i,1);
            break;
          }
        }
        that.setData({
          addressList: addressList
        })
      }
    })
  },
  getAddress() {
    let that = this;
    wx.getSetting({
      success: (res) => {
        if (!res.authSetting['scope.address']) {
          wx.authorize({
            scope: 'scope.address',
            success() {
              wx.chooseAddress({
                success(res) {
                  let address = that.data.address;
                  address.name = res.userName;
                  address.mobile = res.telNumber;
                  address.address = res.detailInfo;
                  wx.setStorageSync("wxName", res.userName)
                  wx.setStorageSync("wxMobile", res.telNumber)
                  wx.setStorageSync("wxAddress", res.detailInfo)
                  wx.navigateTo({
                    url: '/pages/ucenter/address/add'
                  })
                }
              })
            },
            fail: (res) => {
              wx.navigateTo({
                url: '/pages/auth/auth'
              })
            }
          })
        } else {
          wx.chooseAddress({
            success(res) {
              console.log(res)
              let address = that.data.address;
              address.name = res.userName;
              address.mobile = res.telNumber;
              address.address = res.detailInfo;
              wx.setStorageSync("wxName", res.userName)
              wx.setStorageSync("wxMobile", res.telNumber)
              wx.setStorageSync("wxAddress", res.detailInfo)
              wx.navigateTo({
                url: '/pages/ucenter/address/add'
              })
            }
          })
        }
      }
    });

  },
  postAddress() {
    let address = this.data.address;
    console.log(address);
    util.request(api.AddressSave, {
      id: address.id,
      name: address.name,
      mobile: address.mobile,
      provinceId: 0,
      cityId: 0,
      areaId: 0,
      address: address.address,
      addressJson: address.region,
      isDefault: address.isDefault,
      provinceName: address.provinceName,
      cityName: address.cityName,
      countyName: address.areaName
    }, 'POST').then(function (res) {
      console.log(res);
      if (res.errno === 0) {
        console.log("success");
      }
    });
  }
})