// pages/ucenter/bind/phone.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolName:'',
    areaName: '',
    userContact: '',
    remark: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '新增学校申请'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  schoolNameInput(e){
    this.setData({
      schoolName:e.detail.value
    })
  },
  areaNameInput(e) {
    this.setData({
      areaName: e.detail.value
    })
  },
  userContactInput(e) {
    this.setData({
      userContact: e.detail.value
    })
  },
  remarkInput(e) {
    this.setData({
      remark: e.detail.value
    })
  },
  newSchoolSubmit:function(){
    if (wx.getStorageSync("school-apply")!==""){
      wx.showModal({
        title: '提示',
        content: '您已经提交过学校申请，请等待客服处理。',
      })
      return false;
    }
    var that = this;
    var schoolName = this.data.schoolName
    var areaName = this.data.areaName
    var userContact = this.data.userContact
    if (schoolName === '' || areaName === '' || userContact===''){
      wx.showModal({
        title: '提示',
        content: '请完整填写您的信息，方便进行评估',
      })
      return false;
    }
    var remark = this.data.remark
    util.request(api.NewSchoolApply, { 
      schoolName: schoolName,
      areaName: areaName,
      userContact: userContact,
      remark: remark
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.setStorageSync("school-apply", "0");
        wx.showModal({
          title: '提示',
          content: '您的申请已提交，我们会收集信息进行学校评估，感谢您的支持。',
          showCancel:false,
          success:function(){
            wx.navigateBack({
              delta:1
            })
          }
        })
      }
    })
  }
})