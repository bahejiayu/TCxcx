// pages/ucenter/bind/phone.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolName:'',
    areaName: '',
    contactName: '',
    contactMobile: '',
    contactDesc:'',
    contactRemark:'',
    appUrl: 'https://banma.laoyeshow.cn/sfimage/app',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '招募合伙人'
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  schoolNameInput(e){
    this.setData({
      schoolName:e.detail.value
    })
  },
  areaNameInput(e) {
    this.setData({
      areaName: e.detail.value
    })
  },
  contactNameInput(e) {
    this.setData({
      contactName: e.detail.value
    })
  },
  contactMobileInput(e) {
    this.setData({
      contactMobile: e.detail.value
    })
  },
  contactDescInput(e) {
    this.setData({
      contactDesc: e.detail.value
    })
  },
  contactRemarkInput(e) {
    this.setData({
      contactRemark: e.detail.value
    })
  },
  newSchoolSubmit:function(){
    if (wx.getStorageSync("cooperation-apply")!==""){
      wx.showModal({
        title: '提示',
        content: '您已经提交过申请，请等待客服处理。',
      })
      return false;
    }
    var that = this;
    var schoolName = this.data.schoolName
    var areaName = this.data.areaName
    var contactName = this.data.contactName
    var contactMobile = this.data.contactMobile
    var contactDesc = this.data.contactDesc
    var contactRemark = this.data.contactRemark
    if (schoolName === '' || areaName === '' || contactName === '' || contactMobile===""){
      wx.showModal({
        title: '提示',
        content: '请完整填写您的信息，方便进行评估',
      })
      return false;
    }
    var remark = this.data.remark
    util.request(api.SysCoopeation, { 
      schoolName: schoolName,
      areaName: areaName,
      contactName: contactName,
      contactMobile: contactMobile,
      contactDesc: contactDesc,
      contactRamark: contactRemark
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.setStorageSync("cooperation-apply", "0");
        wx.showModal({
          title: '提示',
          content: '您的申请已提交，我们会收集信息进行学校评估，感谢您的支持。',
          showCancel:false,
          success:function(){
            wx.navigateBack({
              delta:1
            })
          }
        })
      }
    })
  }
})