// pages/ucenter/bind/phone.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    validCodeTime: 60,
    userMobile: null,
    validCode: null,
    validCodeFlag: true,
    orgName: '',
    orgId: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var orgId = wx.getStorageSync("defaultOrg");
    var orgName = wx.getStorageSync("defaultOrgName");
    this.setData({
      orgId: orgId,
      orgName: orgName
    })
  },
  bindMobile() {
    var that = this;
    var mobile = this.data.userMobile;
    var validCode = this.data.validCode
    if (validCode == "" || validCode == null) {
      wx.showModal({
        title: '提示',
        content: '请输入短信验证码',
      })
      return false;
    }
    if (mobile == "" || mobile == null) {
      wx.showModal({
        title: '提示',
        content: '请输入您的手机号',
      })
      return false;
    }
    if (mobile.length != 11) {
      wx.showModal({
        title: '提示',
        content: '请输入11位电话号码',
      })
      return false;
    }
    if (isNaN(mobile)) {
      wx.showModal({
        title: '提示',
        content: '请填写正确的11位手机号码',
      })
      return false;
    }
    util.request(api.UnBundlingMobil, { oldMobil: mobile, verificationCode: validCode}, "POST").then(function (res) {
      if (res.errno === 0) {
        wx.setStorageSync("userMobile", mobile);
        wx.navigateBack({
          delta: 1
        })
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
        return false;
      }
    })
  },
  validCodeTimer: function () {
    let that = this;
    if (this.data.validCodeTime == 0) {
      this.setData({
        validCodeFlag: true,
        validCodeTime: 10
      })
    } else {
      setTimeout(function () {
        that.setData({
          validCodeTime: that.data.validCodeTime - 1
        })
        that.validCodeTimer();
      }, 1000)
    }
  },
  userMobileInput: function (e) {
    this.setData({
      userMobile: e.detail.value
    })
  },
  validCodeInput: function (e) {
    this.setData({
      validCode: e.detail.value
    })
  },
  sendSms: function () {//发送验证码
    if (!this.data.validCodeFlag) {
      return false;
    }
    var that = this;
    var mobile = this.data.userMobile;
    if (mobile == "" || mobile == null) {
      wx.showModal({
        title: '提示',
        content: '请输入您的手机号',
      })
      return false;
    }
    if (mobile.length != 11) {
      wx.showModal({
        title: '提示',
        content: '请输入11位电话号码',
      })
      return false;
    }
    if (isNaN(mobile)) {
      wx.showModal({
        title: '提示',
        content: '请填写正确的11位手机号码',
      })
      return false;
    }
    util.request(api.SendSms, { mobile: this.data.userMobile }, "POST").then(function (res) {
      if (res.errno === 0) {
        console.log("已发送短信，请注意查收。")
        that.setData({
          validCodeFlag: false
        })
        that.validCodeTimer();
      } else {
        if (res.errno == 501) {
          wx.switchTab({
            url: '/pages/ucenter/home/home',

          })
        } else {
          wx.showModal({
            title: '提示',
            content: res.errmsg,
          })
        }
      }
    })
  },
  gotoDisclaimer() {//跳转到选择学校页面
    wx.navigateTo({
      url: '/pages/ucenter/disclaimer/disclaimer',
    })
  },
})