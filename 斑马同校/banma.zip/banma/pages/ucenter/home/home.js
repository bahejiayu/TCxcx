const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
const user = require('../../../utils/user.js');
Page({
  data: {
    page: 'ucenter',
    auth: 0, //实名认证
    loginAuth: false, //登录认证
    userName: '游客',
    userHeadIcon: 'http://image.weilanwl.com/img/square-2.jpg',
    userLevel: 1,
    userOrgName: '',
    userOrgId: 0,
    userId: 0,
    userType: 0,
    userStatus: 0,
    userBalance: 0.0,
    userSex: 0, //0男 1女
    unreadMsg: 0,
    profileCount: 0,
  },
  toHome() {
    wx.switchTab({
      url: '/pages/home/home',
    });
  },
  showModal(e) {
    var showName = e.currentTarget.dataset.modal;
    this.setData({
      modalName: showName
    })
  },
  closeModal(e) {
    this.setData({
      modalName: null
    })
  },
  onPullDownRefresh: function () {
    this.getIndexData();
    wx.stopPullDownRefresh();
  },
  onShow: function () {
    var that = this;
    // var userAuth = wx.getStorageSync("userAuth");
    // if (userAuth!==""){
    //   this.setData({
    //     auth:3
    //   })
    // }
    setTimeout(function () {
      if (that.data.userType == 2) {
        that.profileCount()
      }
    }, 1000)
    this.messageUnreadCount()
    this.getUserCash()
  },
  onLoad: function () {
    var that = this;
    if (wx.getStorageSync("userInfo") != null && wx.getStorageSync("userInfo") !== "" && wx.getStorageSync("userInfo") !== undefined) {
      this.getIndexData();
      return false;
    }
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo'] === undefined || res.authSetting['scope.userInfo'] === "" || !res.authSetting['scope.userInfo']) {
          that.setData({
            loginAuth: true
          })
          wx.showToast({
            title: '请先授权登录',
            icon: 'loading',
            duration: 2000
          })
        } else {

          that.getUserInfo();
        }
      }
    })
  },
  getUserInfo: function () {
    var that = this;
    wx.getUserInfo({
      success(res) {
        //判断用户是否存在系统，如果没有则新增
        user.loginByWeixin(res.userInfo).then(res => {
          that.setData({
            loginAuth: false
          })
          wx.hideLoading()
          that.getIndexData();
        })
      }
    })
  },
  getIndexData: function () {
    var that = this;
    util.request(api.GetUserData, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          auth: obj.userInfo.type,
          userName: obj.userInfo.userName,
          userHeadIcon: obj.userInfo.userHeadIcon,
          userLevel: obj.level.levelGrade,
          userOrgName: obj.sysOrg == undefined ? '' : obj.sysOrg.orgName,
          userOrgId: obj.sysOrg == undefined ? '' : obj.sysOrg.orgId,
          userBalance: obj.cash.amt == null ? 0.0 : parseFloat(obj.cash.amt).toFixed(2),
          userSex: obj.userInfo.userSex,
          userType: obj.userInfo.manageOrgId != null ? 2 : 0,
          userStatus: obj.userInfo.status,
          userId: obj.userInfo.userId,
        })
        wx.setStorageSync("userId", obj.userInfo.userId);
        if (obj.userInfo.userMobile != null) {
          wx.setStorageSync("userMobile", obj.userInfo.userMobile);
        }
        wx.setStorageSync("userHeadIcon", obj.userInfo.userHeadIcon);
      }
    })
  },
  bindGetUserInfo: function (e) {
    // this.setData({
    //   auth: false
    // })
    this.getUserInfo(10);
    //

  },
  gotoPage: function (e) {
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: url,
    })
  },
  gotoJuan: function (e) {
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: url,
    })
  },
  //所有按钮埋点，用于推送
  formSubmit1: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: "/pages/ucenter/order/order?type=0",
    })
  },
  formSubmit2: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    wx.navigateTo({
      url: "/pages/ucenter/order/order?type=1",
    })
  },
  formSubmit3: function (e) {
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    wx.navigateTo({
      url: "/pages/manager/home",
    })
  },
  formSubmit4: function (e) {
    var that = this
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    util.request(api.OpenCustomerMess, {
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        var otherId = res.data.userMessage.sendUserId
        var icon = res.data.manager == null ? that.data.userHeadIcon : res.data.manager.userHeadIcon
        if (res.data.userMessage.targetUserId == that.data.userId) {
          otherId = res.data.userMessage.targetUserId
        }
        that.gotoMessDetailPage(icon, res.data.userMessage.messId, otherId);
        // wx.navigateTo({
        //   url: "/pages/manager/home",
        // })
      } else {
        wx.showModal({
          title: '提示',
          content: res.errmsg,
        })
      }
    })
  },
  formSubmit5: function (e) {
    var that = this
    var formId = e.detail.formId == "the formId is a mock one" ? "" : e.detail.formId
    util.request(api.SaveUserForm, {
      formId: formId
    }, "POST").then(function (res) {
      if (res.errno === 0) { }
    })
    wx.navigateTo({
      url: "/pages/chat/list",
    })
  },
  gotoMessDetailPage: function (icon, id, otherId) {
    wx.setStorageSync("targetHeadIcon", icon)
    wx.setStorageSync("messageId", id)
    wx.navigateTo({
      url: '/pages/chat/info?messageId=' + id + "&otherUserId=" + otherId,
    })
  },
  profileCount: function (e) {
    var that = this
    util.request(api.ProfileCount, {
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        if (res.data.withdrawCount > 0 && that.data.userStatus == 10) {
          wx.showToast({
            title: '有新的提现审核',
            icon: 'loading',
            duration: 2000
          })
        }
        that.setData({
          profileCount: res.data.count + res.data.withdrawCount
        })

      }
    })
  },
  messageUnreadCount: function (e) {
    var that = this
    util.request(api.UnreadMsgCount, {
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        that.setData({
          unreadMsg: res.data.count
        })
      }
    })
  },
  getUserCash: function () {
    var that = this;
    util.request(api.GetUserCashDetail, {}, "POST").then(function (res) {
      if (res.errno === 0) {
        var obj = res.data;
        that.setData({
          // userBalance: res.data.userCash,
          userBalance: res.data.userCash.amt
        })
      }
    })
  },
})