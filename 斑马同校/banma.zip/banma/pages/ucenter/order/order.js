// pages/ucenter/order/order.js
const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type:0,//0我的发布 1我的抢单,\
    orderList:[],
    orderPageNum:1,
    over: true,
    userId:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      type:options.type==undefined?0:options.type,
      userId: wx.getStorageSync("userId"),
    })
    if (this.data.userId == 0 || this.data.userId == "") {
      wx.navigateBack({
        delta: 1
      })
    } else {
      this.orderList();
    }
    // this.orderList();
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.over) {
      this.orderList();
    }

  },
  orderList: function () {
    var that = this;
    var status=100;
    var id1=null;
    var id2=null;
    if(this.data.type==0){
      status=0
      id1 = this.data.userId
    }else{
      status = 0
      id2 = this.data.userId
    }
    util.request(api.AllOrder, { 
      status: status, 
      pageNum: that.data.orderPageNum, 
      pageSize: 20,
      earnUserId:id2,
      userId:id1
    }, "POST").then(function (res) {
      if (res.errno === 0) {
        var list = res.data.list;
        //解析时间 x小时前| mm-dd hh:mm
        //小于24小时86400000 
        var obj = null;
        var now = new Date().getTime();
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime3(obj.create_date);
          obj.type_desc = obj.type == 0 ? '快递' : obj.type == 1 ? '代购' : '其他'
          obj.status = util.orderStatus(obj.status);
        }

        if (list.length >= 20) {
          that.setData({
            orderPageNum: that.data.orderPageNum + 1,
            over: false
          })
        } else {
          that.setData({
            over: true
          })
        }
        that.setData({
          orderList: that.data.orderList.concat(list),
        })
      } else {
        that.setData({
          over: true
        })
      }
    })
  },
  gotoDetail:function(e){//进入详情页
    var id=e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/task/info?orderId='+id,
    })
  }
})