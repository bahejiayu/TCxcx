const util = require('../../../utils/util.js');
const api = require('../../../config/api.js');
Page({
  data: {
    userAgreement: null
  },
  onLoad: function() {
    var that = this;
    util.request(
      api.ServiceAgreement, {
        agrType: 'SERVICE'
      },
      'POST'
    ).then(function(res) {
      if (res.errno === 0) {
        console.log(res.data);
        var dataInfo = res.data.agrContent.replace(/\<p/gi, '<p class="p"');
        that.setData({
          userAgreement: res.data,
          dataInfo: dataInfo
        });
      }
    })
  },

})