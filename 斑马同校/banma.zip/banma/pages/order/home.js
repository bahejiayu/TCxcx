const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({
  data: {
    TabCur: 0,
    list: [
      [],
      []
    ],
    page: [1, 1],
    userId: 0,
    over:false
  },
  onLoad() {
    this.setData({
      userId: wx.getStorageSync("userId"),
    })
    if (this.data.userId == 0 || this.data.userId == "") {
      wx.navigateBack({
        delta: 1
      })
    } else {
      //this.getOrder();
    }
  },
  onShow(){
    this.getOrder();
  },
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id
    })
    this.getOrder();
  },
  onPullDownRefresh() {
    wx.stopPullDownRefresh();
    this.setData({
      list: [
        [],
        []
      ],
      page: [1, 1]
    })
    // 显示顶部刷新图标
    wx.showNavigationBarLoading();
    this.getOrder();
  },
  getOrder() {
    if (this.data.page[this.data.TabCur] == 0) {
      return false
    }
    var that = this;
    var status = 100;
    var id1 = null;
    var id2 = null;
    if (this.data.TabCur == 0) {
      status = 0
      id1 = this.data.userId
    } else {
      status = 0
      id2 = this.data.userId
    }
    util.request(api.AllOrder, {
      status: status,
      pageNum: that.data.page[that.data.TabCur],
      pageSize: 20,
      earnUserId: id2,
      userId: id1
    }, "POST").then(function(res) {
      if (res.errno === 0) {
        var list = res.data.list;
        //解析时间 x小时前| mm-dd hh:mm
        //小于24小时86400000 
        var obj = null;
        var now = new Date().getTime();
        for (var i = 0; i < list.length; i++) {
          obj = list[i];
          obj.create_date = util.formatTime3(obj.create_date);
          obj.type_desc = obj.type == 0 ? '快递' : obj.type == 1 ? '代购' : obj.type == 2 ? '打印' : '其他'
          obj.status = util.orderStatus(obj.status);
        }
        var page = that.data.page
        if (list.length >= 20) {
          page[that.data.TabCur] = page[that.data.TabCur] + 1;
        } else {
          page[that.data.TabCur] = 0;
        }
        that.setData({
          page: page
        })
        let List = that.data.list;
        List[that.data.TabCur] = List[that.data.TabCur].concat(list),
          that.setData({
            list: List,
          })
      } else {
        that.setData({
          over: true
        })
      }
      setTimeout(() => {
        // 隐藏导航栏加载框
        wx.hideNavigationBarLoading();
        // 停止下拉动作
      }, 1000)
    })
  },
  gotoDetail(e){
    var id = e.currentTarget.dataset.id;
    var uid = e.currentTarget.dataset.uid;
    var sex = e.currentTarget.dataset.sex;
    wx.navigateTo({
      url: '/pages/task/info?orderId=' + id,
    })
  }
})