const util = require('../../utils/util.js');
const api = require('../../config/api.js');
Page({
  data: {
   linkPic:""
  },
  onLoad: function (options) {
   var that=this;
    that.setData({
      linkPic: options.linkPic
    });
  },
  previewImg: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src + '', // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  },
})