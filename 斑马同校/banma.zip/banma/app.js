//app.js
App({
  globalData: {
    userInfo: null
  }
})